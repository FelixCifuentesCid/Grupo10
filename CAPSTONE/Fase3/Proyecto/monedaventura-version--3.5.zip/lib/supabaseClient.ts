
import { createClient } from '@supabase/supabase-js';

// Cast import.meta to any to avoid TypeScript errors with Vite env vars
const metaEnv = (import.meta as any).env;

// ---------------------------------------------------------------------------
// CONFIGURACIÓN DE SUPABASE
// ---------------------------------------------------------------------------
// La URL real te la da Supabase.com al crear el proyecto (Settings -> API).
// Suele tener letras y números aleatorios (ej: https://xyz123.supabase.co).
//
// Mientras tanto, usamos esta URL con el nombre del juego para que no falle:
const DEFAULT_URL = 'https://monedaventura-app.supabase.co'; 
const DEFAULT_KEY = 'coloca-aqui-tu-anon-key-de-supabase';

// Intentamos leer del archivo .env, si no existe, usamos los valores por defecto
const SUPABASE_URL = metaEnv?.VITE_SUPABASE_URL || DEFAULT_URL;
const SUPABASE_ANON_KEY = metaEnv?.VITE_SUPABASE_ANON_KEY || DEFAULT_KEY;

// Función para validar que la URL no rompa la aplicación
const isValidUrl = (url: string) => {
  try {
    return Boolean(new URL(url));
  } catch (e) {
    return false;
  }
};

// Si la URL está mal escrita o vacía, usamos la por defecto para evitar pantalla blanca
const finalUrl = isValidUrl(SUPABASE_URL) ? SUPABASE_URL : DEFAULT_URL;

export const supabase = createClient(finalUrl, SUPABASE_ANON_KEY);
