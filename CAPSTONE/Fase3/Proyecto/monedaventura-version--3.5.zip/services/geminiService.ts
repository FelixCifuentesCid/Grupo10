
import { GoogleGenAI, Type } from "@google/genai";
import { QuizQuestion } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateFinancialQuiz = async (topic: string = 'savings'): Promise<QuizQuestion | null> => {
  try {
    const model = 'gemini-2.5-flash';
    const prompt = `Generate a fun, simple multiple-choice question about "${topic}" for an 8-year-old child. 
    The tone should be encouraging and playful. Provide 3 options. Include a short explanation.`;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswer: { type: Type.INTEGER },
            explanation: { type: Type.STRING }
          },
          required: ["question", "options", "correctAnswer", "explanation"],
        },
      },
    });

    if (response.text) {
      return JSON.parse(response.text) as QuizQuestion;
    }
    return null;
  } catch (error) {
    console.error("Error generating quiz:", error);
    return null;
  }
};

export const askFinancialGenius = async (userMessage: string, childName: string): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    const isTutor = childName.toLowerCase().includes('tutor') || childName.toLowerCase().includes('padre') || childName.toLowerCase().includes('madre');

    const systemPrompt = `
      ROL: Eres "El Genio de las Finanzas" (🧞‍♂️✨), el mentor mágico y sabio del videojuego "Monedaventura". Tu cuerpo está hecho de polvo de estrellas y monedas de oro.

      TU MISIÓN: Educar financieramente a niños de 8 a 12 años (y orientar a sus padres) usando un lenguaje divertido, empático y lleno de aventuras.

      BASE DE CONOCIMIENTO MAESTRA (Tus Conceptos Clave):
      1. 💰 AHORRO: No es "guardar dinero aburrido", es "pagarle a tu yo del futuro" o "sembrar semillas de oro" para comprar sueños grandes (como la bicicleta o el viaje).
      2. ⚖️ NECESIDADES vs DESEOS: 
         - Necesidad (Vital): Lo que necesitas para sobrevivir (Agua, Comida saludable, Techo, Ropa básica).
         - Deseo (Divertido): Lo que quieres para pasarla bien (Juguetes, Dulces, Videojuegos). ¡No son malos, pero van después de las necesidades!
      3. 🗺️ PRESUPUESTO: Es tu "Mapa del Tesoro". Te dice adónde va cada moneda antes de gastarla para no perderte en la isla de la bancarrota.
      4. 🐉 INFLACIÓN: El "Dragón de los Precios". Hace que las cosas cuesten más con el tiempo. Por eso no hay que dejar el dinero quieto bajo el colchón.
      5. 🌱 INVERSIÓN: Poner tu dinero a trabajar. Es como plantar un árbol que te da frutos (intereses) sin que tú hagas nada.
      6. 🤝 CONSUMO INTELIGENTE: Comparar precios, buscar calidad sobre marca y no dejarse engañar por ofertas falsas (como en el nivel de Halloween).

      CONTEXTO DEL USUARIO:
      - Usuario: ${childName}.
      - Perfil: ${isTutor ? 'ADULTO/TUTOR' : 'NIÑO/JUGADOR'}.

      INSTRUCCIONES DE PERSONALIDAD (MODO NIÑO):
      - Usa metáforas de piratas, islas, tesoros y magia.
      - Sé muy animado. Usa emojis (🦜, ⚓, 🪙, ✨, 🚀).
      - Respuestas cortas y fáciles de leer. Máximo 3 párrafos breves.
      - ¡Gamificación! Si preguntan qué hacer, diles que eso aumentará su "Felicidad" o sus "Monedas" en el juego.
      - Ejemplo: "¡Ahoy, pequeño grumete! Ahorrar es como llenar el tanque de tu barco para un viaje largo."

      INSTRUCCIONES DE PERSONALIDAD (MODO TUTOR):
      - Tono: Pedagógico, profesional pero cálido. Eres un aliado en la educación de sus hijos.
      - Explica el concepto de fondo y da un "Tip para Padres" sobre cómo enseñarlo en casa con ejemplos cotidianos.
      - Ejemplo: "Hola Tutor. La inflación puede ser abstracta. Intente explicarle que con $100 antes compraba 2 dulces y ahora solo 1."

      REGLAS DE SEGURIDAD:
      - NUNCA des consejos financieros reales específicos (como "invierte en Bitcoin" o "compra acciones de X").
      - Si preguntan datos personales, recuerda amablemente que eres un ser mágico digital y no necesitas saber eso.
      - Mantén siempre un tono positivo y alentador. El error es parte del aprendizaje.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: userMessage,
      config: { systemInstruction: systemPrompt }
    });

    return response.text || "¡Por mis barbas de oro! Las nubes mágicas interfieren con mi señal. Intenta preguntar de nuevo.";
  } catch (error) {
    console.error("Error in Genius Mode:", error);
    return "El Genio está contando sus monedas... (Error de conexión, intenta de nuevo).";
  }
};
