
import React from 'react';
import { GameButton } from '../components/GameButton';
import { CoinIcon } from '../components/CoinIcon';
import { Cloud } from 'lucide-react';

interface LandingPageProps {
  onLogin: () => void;
  onCreateAccount: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onLogin, onCreateAccount }) => {
  return (
    <div className="fixed inset-0 h-[100dvh] w-full bg-[#38bdf8] overflow-hidden font-sans flex flex-col">
      
      {/* --- Background Elements (Sky) --- */}
      <div className="absolute top-5 left-[-10%] opacity-60 animate-float pointer-events-none">
          <Cloud size={120} fill="white" className="text-white" strokeWidth={0} />
      </div>
      <div className="absolute top-20 right-[-5%] opacity-80 animate-float delay-1000 pointer-events-none">
          <Cloud size={150} fill="white" className="text-white" strokeWidth={0} />
      </div>
      <div className="absolute top-1/3 left-1/4 opacity-40 animate-float delay-500 pointer-events-none scale-75">
          <Cloud size={100} fill="white" className="text-white" strokeWidth={0} />
      </div>

      {/* Floating Coins in Background */}
      <div className="absolute top-[15%] left-[5%] animate-bounce duration-[3000ms] opacity-90 pointer-events-none"><CoinIcon size={56} className="-rotate-12" /></div>
      <div className="absolute top-[40%] right-[10%] animate-bounce duration-[4000ms] delay-500 opacity-90 pointer-events-none"><CoinIcon size={48} className="rotate-12" /></div>
      <div className="absolute top-[25%] left-[30%] animate-bounce duration-[3500ms] delay-200 opacity-80 pointer-events-none"><CoinIcon size={32} /></div>

      {/* --- Main Content Area --- */}
      <div className="relative z-20 flex flex-col items-center w-full px-4 pt-12 md:pt-16 lg:pt-20">
        
        {/* Title Section */}
        <div className="text-center mb-8 animate-bounce-in origin-top">
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-black tracking-wide title-stroke rotate-[-2deg] leading-tight">
            MONEDAVENTURA
          </h1>
          <h2 className="font-display text-lg md:text-2xl font-black tracking-wider subtitle-stroke rotate-[1deg] mt-2">
            APRENDE FINANZAS JUGANDO
          </h2>
        </div>

        {/* Buttons Section */}
        <div className="flex flex-col gap-4 w-full max-w-xs md:max-w-sm z-30">
          <button 
            onClick={onCreateAccount}
            className="bg-[#fbbf24] hover:bg-[#f59e0b] text-[#78350f] font-display font-black text-xl py-4 px-6 rounded-2xl border-b-[6px] border-[#b45309] shadow-xl active:border-b-0 active:translate-y-1 transition-all"
          >
            CREAR NUEVA CUENTA
          </button>
          
          <button 
            onClick={onLogin}
            className="bg-[#0284c7] hover:bg-[#0369a1] text-white font-display font-black text-xl py-4 px-6 rounded-2xl border-b-[6px] border-[#0c4a6e] shadow-xl active:border-b-0 active:translate-y-1 transition-all"
          >
            INICIAR SESIÓN
          </button>
        </div>

      </div>

      {/* --- Landscape & Characters (Bottom) --- */}
      <div className="absolute bottom-0 w-full h-[45%] z-10">
         
         {/* Grass Hills */}
         <div className="absolute bottom-0 left-0 w-full h-full bg-grass-400 rounded-t-[50px] md:rounded-t-[100px] border-t-[8px] border-grass-600 shadow-inner overflow-hidden">
            {/* Decorative darker grass patch */}
            <div className="absolute bottom-[-20%] left-[-20%] w-[70%] h-[80%] bg-grass-500 rounded-full opacity-50"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-grass-500 rounded-full opacity-50"></div>
         </div>

         {/* --- Characters & Props --- */}
         
         {/* Boy (Jack) - Running Left */}
         <div className="absolute bottom-[10%] left-[-5%] md:left-[10%] w-48 md:w-60 animate-float duration-[3000ms]">
             <img 
               src="https://api.dicebear.com/9.x/adventurer/svg?seed=Jack&flip=true"
               alt="Niño Pirata"
               className="w-full h-full object-contain drop-shadow-2xl"
             />
             {/* Shadow */}
             <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-24 h-3 bg-black/20 rounded-full blur-sm"></div>
         </div>

         {/* Girl (Annie) - With Map Right */}
         <div className="absolute bottom-[8%] right-[-5%] md:right-[10%] w-48 md:w-60 animate-float duration-[4000ms] delay-500">
             <img 
               src="https://api.dicebear.com/9.x/adventurer/svg?seed=Annie"
               alt="Niña Pirata"
               className="w-full h-full object-contain drop-shadow-2xl"
             />
             {/* Shadow */}
             <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-24 h-3 bg-black/20 rounded-full blur-sm"></div>
         </div>

         {/* Treasure Chest - Center */}
         <div className="absolute bottom-[5%] left-1/2 -translate-x-1/2 w-32 md:w-40 hover:scale-110 transition-transform cursor-pointer z-20">
            <svg viewBox="0 0 100 100" className="drop-shadow-2xl filter brightness-110">
               <path d="M10,40 Q50,10 90,40 L90,80 Q50,95 10,80 Z" fill="#B45309" stroke="#78350F" strokeWidth="3" />
               <path d="M10,40 Q50,10 90,40" fill="#D97706" stroke="#78350F" strokeWidth="3" />
               <rect x="42" y="50" width="16" height="20" rx="2" fill="#FBBF24" stroke="#B45309" strokeWidth="2" />
               <circle cx="50" cy="58" r="3" fill="#78350F" />
               {/* Coins overflowing */}
               <circle cx="30" cy="35" r="9" fill="#FCD34D" stroke="#B45309" strokeWidth="1" />
               <circle cx="45" cy="28" r="9" fill="#FCD34D" stroke="#B45309" strokeWidth="1" />
               <circle cx="60" cy="32" r="9" fill="#FCD34D" stroke="#B45309" strokeWidth="1" />
            </svg>
         </div>

         {/* Coins on the ground */}
         <div className="absolute bottom-[5%] left-[20%] w-10 opacity-80"><CoinIcon size={40} /></div>
         <div className="absolute bottom-[8%] right-[25%] w-10 opacity-80"><CoinIcon size={36} /></div>
      </div>

    </div>
  );
};
