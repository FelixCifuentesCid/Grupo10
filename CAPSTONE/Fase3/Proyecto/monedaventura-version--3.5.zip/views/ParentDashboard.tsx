
import React, { useState, useRef, useEffect } from 'react';
import { User, ChildProfile } from '../types';
import { AVATARS } from '../data/gameData';
import { GameButton } from '../components/GameButton';
import { Plus, User as UserIcon, LogOut, Settings, Target, Zap, Gift, Edit, Trash2, X, Home, Gamepad2, MoreVertical, ChevronRight, Check, AlertTriangle } from 'lucide-react';
import { CoinIcon } from '../components/CoinIcon';

interface ParentDashboardProps {
  user: User;
  onSelectProfile: (profile: ChildProfile) => void;
  onAddProfile: (name: string, grade: string, avatar: string) => void;
  onEditProfile: (id: string, data: { name: string; grade: string; avatar: string }) => void;
  onDeleteProfile: (id: string) => void;
  onAddGoal: (childId: string, title: string, target: number, icon: string) => void;
  onGiveReward: (childId: string, amount: number) => void;
  onPlayAsTutor: () => void;
  onLogout: () => void;
}

export const ParentDashboard: React.FC<ParentDashboardProps> = ({ 
    user, onSelectProfile, onAddProfile, onEditProfile, onDeleteProfile, onAddGoal, onGiveReward, onPlayAsTutor, onLogout 
}) => {
  const [mode, setMode] = useState<'DASHBOARD' | 'ADD_PROFILE' | 'ADD_GOAL' | 'GIVE_REWARD'>('DASHBOARD');
  
  // Profile Form State
  const [editingProfileId, setEditingProfileId] = useState<string | null>(null);
  const [newName, setNewName] = useState('');
  const [newGrade, setNewGrade] = useState('2º');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATARS[0].id);
  
  // Goal Form State
  const [goalChildId, setGoalChildId] = useState(user.children.length > 0 ? user.children[0].id : '');
  const [goalTitle, setGoalTitle] = useState('');
  const [goalTarget, setGoalTarget] = useState(100);
  const [goalIcon, setGoalIcon] = useState('🚲');

  // Reward Form State
  const [rewardChildId, setRewardChildId] = useState(user.children.length > 0 ? user.children[0].id : '');
  const [rewardAmount, setRewardAmount] = useState(50);

  // UI State
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const GRADES = ['2º', '3º', '4º', '5º', '6º'];
  const GOAL_ICONS = ['🚲', '🎮', '📚', '⚽', '🎸', '📱', '🎨', '👟', '🐕'];

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = () => setActiveDropdown(null);
    window.addEventListener('click', handleClickOutside);
    return () => window.removeEventListener('click', handleClickOutside);
  }, []);

  // --- HANDLERS ---

  const openAddProfile = () => {
      setMode('ADD_PROFILE');
      setEditingProfileId(null);
      setNewName('');
      setNewGrade('2º');
      setSelectedAvatar(AVATARS[0].id);
  };

  const openEditProfile = (e: React.MouseEvent, child: ChildProfile) => {
      e.stopPropagation(); // Prevent card click
      setMode('ADD_PROFILE');
      setEditingProfileId(child.id);
      setNewName(child.name);
      setNewGrade(child.grade);
      setSelectedAvatar(child.avatar);
      setActiveDropdown(null);
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      if(window.confirm("¿Estás seguro de que quieres eliminar este perfil permanentemente? Esta acción no se puede deshacer.")) {
          onDeleteProfile(id);
          setActiveDropdown(null);
      }
  };

  const handleProfileSubmit = () => {
    if (!newName.trim()) return;
    if (editingProfileId) {
        onEditProfile(editingProfileId, { name: newName, grade: newGrade, avatar: selectedAvatar });
    } else {
        onAddProfile(newName, newGrade, selectedAvatar);
    }
    setMode('DASHBOARD');
  };

  const handleGoalSubmit = () => {
      if (!goalTitle.trim() || !goalChildId) return;
      onAddGoal(goalChildId, goalTitle, goalTarget, goalIcon);
      setMode('DASHBOARD');
      setGoalTitle('');
      setGoalTarget(100);
  };

  const handleRewardSubmit = () => {
      if (!rewardChildId) return;
      onGiveReward(rewardChildId, rewardAmount);
      setMode('DASHBOARD');
      setRewardAmount(50);
  };

  const toggleDropdown = (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      setActiveDropdown(activeDropdown === id ? null : id);
  };

  // --- DATA COMPUTATION ---
  const totalCoins = user.children.reduce((acc, child) => acc + child.stats.coins, 0);
  const missionsCompleted = user.children.reduce((acc, child) => acc + child.completedLevels.length, 0);
  
  // Flatten all activity logs, sort by date (newest first), and take top 5
  const recentActivities = user.children
    .flatMap(child => (child.activityLog || []).map(log => ({ ...log, childName: child.name })))
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 5);

  // --- RENDER ---

  return (
    <div className="min-h-screen bg-[#f0f9ff] font-sans flex">
      
      {/* SIDEBAR */}
      <div className="w-20 md:w-64 bg-[#0c4a6e] text-white flex flex-col shrink-0 transition-all duration-300 sticky top-0 h-screen z-50 shadow-2xl">
         <div className="p-4 md:p-8 flex justify-center md:justify-start items-center gap-3 border-b border-sky-800">
             <div className="bg-sky-500 p-2 rounded-xl shadow-lg"><Target className="text-white" size={24}/></div>
             <h1 className="font-display text-2xl font-black hidden md:block tracking-wide text-sky-100">Panel Familiar</h1>
         </div>
         
         <nav className="flex-1 p-4 space-y-2">
             <button className="w-full flex items-center gap-3 p-3 bg-sky-600 rounded-xl shadow-md transition-transform active:scale-95">
                 <Home size={20} /> <span className="hidden md:block font-bold">Inicio</span>
             </button>
             <button onClick={() => setMode('ADD_GOAL')} className="w-full flex items-center gap-3 p-3 text-sky-200 hover:bg-sky-900 hover:text-white rounded-xl transition-colors">
                 <Target size={20} /> <span className="hidden md:block font-bold">Agregar Meta</span>
             </button>
             <button onClick={() => setMode('GIVE_REWARD')} className="w-full flex items-center gap-3 p-3 text-sky-200 hover:bg-sky-900 hover:text-white rounded-xl transition-colors">
                 <Gift size={20} /> <span className="hidden md:block font-bold">Dar Premio</span>
             </button>
         </nav>

         <div className="p-4 border-t border-sky-800">
            <div className="flex items-center gap-3 mb-4 px-2">
                <div className="w-10 h-10 bg-sky-700 rounded-full flex items-center justify-center font-bold text-lg border-2 border-sky-400">{user.username[0].toUpperCase()}</div>
                <div className="hidden md:block overflow-hidden">
                    <p className="font-bold text-sm truncate">{user.username}</p>
                    <p className="text-xs text-sky-300 uppercase font-bold tracking-wider">Tutor</p>
                </div>
            </div>
            <button onClick={onLogout} className="w-full flex items-center gap-2 text-red-300 hover:text-red-100 hover:bg-red-900/30 p-2 rounded-lg text-sm font-bold transition-colors">
                <LogOut size={16} /> <span className="hidden md:block">Cerrar Sesión</span>
            </button>
         </div>
      </div>

      {/* MAIN CONTENT */}
      <div className="flex-1 p-4 md:p-8 overflow-y-auto">
         
         {/* Top Stats */}
         <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-gradient-to-br from-amber-400 to-orange-500 rounded-3xl p-6 text-white shadow-[0_8px_20px_rgba(245,158,11,0.3)] relative overflow-hidden group">
                <div className="absolute right-[-20px] top-[-20px] opacity-20 group-hover:scale-110 transition-transform"><CoinIcon size={120} /></div>
                <h3 className="font-bold text-amber-100 text-sm uppercase tracking-wider mb-1">Total Monedas Familia</h3>
                <div className="text-4xl font-black font-display">{totalCoins}</div>
            </div>
            <div className="bg-gradient-to-br from-sky-400 to-blue-600 rounded-3xl p-6 text-white shadow-[0_8px_20px_rgba(14,165,233,0.3)] relative overflow-hidden group">
                <div className="absolute right-[-20px] top-[-20px] opacity-20 group-hover:scale-110 transition-transform"><Zap size={120} /></div>
                <h3 className="font-bold text-sky-100 text-sm uppercase tracking-wider mb-1">Niveles Completados</h3>
                <div className="text-4xl font-black font-display">{missionsCompleted}</div>
            </div>
             <div className="bg-gradient-to-br from-emerald-400 to-teal-600 rounded-3xl p-6 text-white shadow-[0_8px_20px_rgba(16,185,129,0.3)] relative overflow-hidden group">
                <div className="absolute right-[-20px] top-[-20px] opacity-20 group-hover:scale-110 transition-transform"><Target size={120} /></div>
                <h3 className="font-bold text-emerald-100 text-sm uppercase tracking-wider mb-1">Estudiantes Activos</h3>
                <div className="text-4xl font-black font-display">{user.children.length}</div>
            </div>
         </div>

         {/* Student Profiles */}
         <div className="bg-white rounded-[2rem] p-6 md:p-8 shadow-xl mb-8 border border-slate-100">
             <div className="flex justify-between items-center mb-6">
                 <h2 className="text-2xl font-display font-black text-slate-800 flex items-center gap-2">
                    <UserIcon className="text-sky-500" fill="currentColor" /> Perfiles de Estudiantes
                 </h2>
                 <div className="hidden md:block">
                     <GameButton variant="primary" className="!py-2 !text-sm" onClick={onPlayAsTutor}>Ver Dashboard &gt;</GameButton>
                 </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 {user.children.map(child => (
                     <div key={child.id} onClick={() => onSelectProfile(child)} className="group bg-slate-50 border-2 border-slate-100 hover:border-sky-400 rounded-3xl p-4 transition-all hover:shadow-lg cursor-pointer relative">
                         <div className="flex items-start gap-4">
                             <div className="w-16 h-16 rounded-2xl overflow-hidden bg-white shadow-md border-2 border-slate-200 group-hover:scale-105 transition-transform">
                                 {/* Find actual image from AVATARS constant to render properly */}
                                 <img 
                                    src={AVATARS.find(a => a.id === child.avatar)?.image || AVATARS[0].image} 
                                    alt={child.name} 
                                    className="w-full h-full object-cover"
                                 />
                             </div>
                             <div className="flex-1 min-w-0">
                                 <h3 className="font-black text-lg text-slate-800 truncate">{child.name}</h3>
                                 <p className="text-slate-500 text-sm font-bold">{child.grade} • {child.stats.coins} 🪙</p>
                             </div>
                             
                             {/* Context Menu */}
                             <div className="relative">
                                 <button onClick={(e) => toggleDropdown(e, child.id)} className="p-2 text-slate-400 hover:text-sky-600 hover:bg-sky-50 rounded-full transition-colors">
                                     <MoreVertical size={20} />
                                 </button>
                                 
                                 {activeDropdown === child.id && (
                                     <div className="absolute right-0 top-10 bg-white rounded-xl shadow-2xl border border-slate-100 py-2 w-40 z-[100] animate-in zoom-in-95 duration-100 origin-top-right">
                                         <button onClick={(e) => openEditProfile(e, child)} className="w-full text-left px-4 py-2 text-slate-600 font-bold hover:bg-sky-50 hover:text-sky-600 flex items-center gap-2 text-sm">
                                             <Edit size={16} /> Editar
                                         </button>
                                         <div className="h-px bg-slate-100 my-1"></div>
                                         <button onClick={(e) => handleDelete(e, child.id)} className="w-full text-left px-4 py-2 text-rose-500 font-bold hover:bg-rose-50 flex items-center gap-2 text-sm">
                                             <Trash2 size={16} /> Eliminar
                                         </button>
                                     </div>
                                 )}
                             </div>
                         </div>

                         <div className="mt-4 bg-white rounded-xl p-3 border border-slate-100">
                             <div className="flex justify-between text-xs font-bold text-slate-400 mb-1 uppercase">
                                 <span>Meta Actual</span>
                                 <span>{child.goals && child.goals.length > 0 ? Math.round((child.goals[0].currentAmount / child.goals[0].targetAmount) * 100) : 0}%</span>
                             </div>
                             {child.goals && child.goals.length > 0 ? (
                                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                                    <div className="h-full bg-sky-500 rounded-full" style={{ width: `${Math.min(100, (child.goals[0].currentAmount / child.goals[0].targetAmount) * 100)}%` }}></div>
                                </div>
                             ) : (
                                 <p className="text-xs text-slate-400 italic">Sin metas activas</p>
                             )}
                         </div>
                     </div>
                 ))}

                 {/* Add New Profile Card */}
                 <button onClick={openAddProfile} className="flex flex-col items-center justify-center gap-3 bg-white border-2 border-dashed border-slate-300 hover:border-sky-400 hover:bg-sky-50 rounded-3xl p-6 transition-all h-full min-h-[140px] group text-slate-400 hover:text-sky-600">
                     <div className="bg-slate-100 group-hover:bg-white p-3 rounded-full transition-colors shadow-sm">
                         <Plus size={32} />
                     </div>
                     <span className="font-bold">Nuevo Perfil</span>
                 </button>
             </div>
         </div>

         {/* Recent Activity */}
         <div className="bg-white rounded-[2rem] p-6 md:p-8 shadow-xl border border-slate-100">
             <h2 className="text-xl font-display font-black text-slate-800 mb-6 flex items-center gap-2">
                 <Zap className="text-amber-500" fill="currentColor" /> Actividad Reciente
             </h2>
             <div className="space-y-4">
                 {recentActivities.length > 0 ? recentActivities.map((activity, idx) => (
                     <div key={idx} className="flex items-center justify-between border-b border-slate-50 pb-4 last:border-0 last:pb-0">
                         <div className="flex items-center gap-4">
                             <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 shadow-sm">
                                 <Zap size={20} />
                             </div>
                             <div>
                                 <p className="font-bold text-slate-700">{activity.title}</p>
                                 <p className="text-xs text-slate-400 font-semibold uppercase tracking-wide">{activity.childName} • {activity.timestamp}</p>
                             </div>
                         </div>
                         {activity.coinsEarned !== undefined && activity.coinsEarned !== 0 && (
                             <div className="font-black text-amber-500 bg-amber-50 px-3 py-1 rounded-full text-sm">
                                 +{activity.coinsEarned} 🪙
                             </div>
                         )}
                     </div>
                 )) : (
                     <div className="text-center text-slate-400 py-8 italic">No hay actividad reciente.</div>
                 )}
             </div>
         </div>

      </div>

      {/* --- MODALS --- */}

      {/* ADD / EDIT PROFILE MODAL */}
      {mode === 'ADD_PROFILE' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-lg rounded-3xl p-8 shadow-2xl animate-in zoom-in-95">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-display font-black text-slate-800">
                        {editingProfileId ? 'Editar Estudiante' : 'Nuevo Estudiante'}
                    </h2>
                    <button onClick={() => setMode('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200 text-slate-500">
                        <X size={24} />
                    </button>
                </div>
                
                <div className="space-y-6">
                    <div>
                        <label className="block text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Nombre del Niño/a</label>
                        <input 
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                            className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-800 focus:border-sky-400 focus:bg-white outline-none transition-colors"
                            placeholder="Ej: Sofía"
                        />
                    </div>

                    <div>
                        <label className="block text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Grado Escolar</label>
                        <div className="flex gap-2">
                            {GRADES.map(grade => (
                                <button
                                    key={grade}
                                    onClick={() => setNewGrade(grade)}
                                    className={`flex-1 py-3 rounded-xl font-black border-b-4 active:border-b-0 active:translate-y-1 transition-all
                                        ${newGrade === grade 
                                            ? 'bg-sky-500 text-white border-sky-700 shadow-lg' 
                                            : 'bg-slate-100 text-slate-500 border-slate-300 hover:bg-slate-200'}
                                    `}
                                >
                                    {grade}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <label className="block text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Elige un Avatar</label>
                        <div className="grid grid-cols-4 gap-3 h-40 overflow-y-auto p-2 bg-slate-50 rounded-2xl border-2 border-slate-200">
                            {AVATARS.map(avatar => (
                                <button
                                    key={avatar.id}
                                    onClick={() => setSelectedAvatar(avatar.id)}
                                    className={`aspect-square rounded-xl overflow-hidden border-2 transition-all relative
                                        ${selectedAvatar === avatar.id ? 'border-sky-500 ring-2 ring-sky-200 scale-105 z-10' : 'border-transparent hover:border-slate-300 opacity-70 hover:opacity-100'}
                                    `}
                                >
                                    <img src={avatar.image} alt={avatar.name} className="w-full h-full object-cover" />
                                    {selectedAvatar === avatar.id && (
                                        <div className="absolute inset-0 bg-sky-500/20 flex items-center justify-center">
                                            <Check className="text-white drop-shadow-md" strokeWidth={3} />
                                        </div>
                                    )}
                                </button>
                            ))}
                        </div>
                    </div>

                    <GameButton onClick={handleProfileSubmit} fullWidth className="mt-4">
                        {editingProfileId ? 'Guardar Cambios' : 'Crear Perfil'}
                    </GameButton>
                </div>
            </div>
        </div>
      )}

      {/* ADD GOAL MODAL */}
      {mode === 'ADD_GOAL' && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-lg rounded-3xl p-8 shadow-2xl animate-in zoom-in-95">
                  <div className="flex justify-between items-center mb-6">
                      <h2 className="text-2xl font-display font-black text-slate-800 flex items-center gap-2">
                          <Target className="text-pink-500" /> Nueva Meta de Ahorro
                      </h2>
                      <button onClick={() => setMode('DASHBOARD')} className="bg-slate-100 p-2 rounded-full hover:bg-slate-200 text-slate-500"><X size={24} /></button>
                  </div>

                  <div className="space-y-6">
                      <div>
                          <label className="block text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">¿Para quién es la meta?</label>
                          <select 
                            value={goalChildId} 
                            onChange={(e) => setGoalChildId(e.target.value)}
                            className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-700 outline-none focus:border-pink-400"
                          >
                              {user.children.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                          </select>
                      </div>

                      <div>
                          <label className="block text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Nombre de la Meta</label>
                          <input 
                            value={goalTitle} onChange={(e) => setGoalTitle(e.target.value)}
                            placeholder="Ej: Bicicleta Nueva"
                            className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-800 focus:border-pink-400 outline-none"
                          />
                      </div>

                      <div>
                          <label className="block text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Monto Objetivo (Monedas)</label>
                          <div className="flex items-center gap-4">
                             <button onClick={() => setGoalTarget(Math.max(10, goalTarget - 10))} className="bg-slate-200 p-3 rounded-xl font-black text-slate-600 hover:bg-slate-300">-</button>
                             <div className="flex-1 bg-slate-50 border-2 border-slate-200 p-3 rounded-xl text-center font-black text-xl text-slate-800 flex items-center justify-center gap-2">
                                <CoinIcon size={24} /> {goalTarget}
                             </div>
                             <button onClick={() => setGoalTarget(goalTarget + 10)} className="bg-slate-200 p-3 rounded-xl font-black text-slate-600 hover:bg-slate-300">+</button>
                          </div>
                      </div>

                      <div>
                          <label className="block text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Icono</label>
                          <div className="flex gap-2 overflow-x-auto pb-2">
                              {GOAL_ICONS.map(icon => (
                                  <button 
                                    key={icon} 
                                    onClick={() => setGoalIcon(icon)}
                                    className={`w-12 h-12 rounded-xl text-2xl flex items-center justify-center border-2 transition-all ${goalIcon === icon ? 'bg-pink-100 border-pink-500 scale-110' : 'bg-slate-50 border-slate-200'}`}
                                  >
                                      {icon}
                                  </button>
                              ))}
                          </div>
                      </div>

                      <GameButton onClick={handleGoalSubmit} variant="success" fullWidth>Crear Meta</GameButton>
                  </div>
              </div>
          </div>
      )}

      {/* GIVE REWARD MODAL */}
      {mode === 'GIVE_REWARD' && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
              <div className="bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl animate-in zoom-in-95 border-4 border-yellow-400">
                  <div className="text-center mb-6">
                      <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4 text-yellow-600 animate-bounce">
                          <Gift size={40} />
                      </div>
                      <h2 className="text-2xl font-display font-black text-slate-800">¡Dar Recompensa!</h2>
                      <p className="text-slate-500 font-bold text-sm">Premia el buen comportamiento</p>
                  </div>

                  <div className="space-y-6">
                      <select 
                        value={rewardChildId} 
                        onChange={(e) => setRewardChildId(e.target.value)}
                        className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl font-bold text-slate-700 outline-none focus:border-yellow-400"
                      >
                          {user.children.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>

                      <div className="grid grid-cols-3 gap-3">
                          {[20, 50, 100].map(amount => (
                              <button 
                                key={amount} 
                                onClick={() => setRewardAmount(amount)}
                                className={`py-4 rounded-2xl font-black border-b-4 active:translate-y-1 active:border-b-0 transition-all flex flex-col items-center gap-1
                                    ${rewardAmount === amount ? 'bg-yellow-400 border-yellow-600 text-yellow-900 shadow-lg' : 'bg-slate-100 border-slate-300 text-slate-400 hover:bg-yellow-50'}
                                `}
                              >
                                  <span className="text-2xl">+{amount}</span>
                                  <CoinIcon size={20} />
                              </button>
                          ))}
                      </div>

                      <GameButton onClick={handleRewardSubmit} fullWidth>Enviar Monedas</GameButton>
                      <button onClick={() => setMode('DASHBOARD')} className="w-full py-3 text-slate-400 font-bold hover:text-slate-600">Cancelar</button>
                  </div>
              </div>
          </div>
      )}

    </div>
  );
};
