
import React, { useState } from 'react';
import { ChildProfile, LevelData } from '../types';
import { MAPS, LEVELS, AVATARS } from '../data/gameData';
import { CoinIcon } from '../components/CoinIcon';
import { Heart, Flame, Menu, X, Share2, Map as MapIcon, Gamepad2, Sparkles, LogOut, Lock, Check, Music, Volume2, VolumeX } from 'lucide-react';
import { GameButton } from '../components/GameButton';

interface ChildDashboardProps {
  profile: ChildProfile;
  rewardAvailable: boolean;
  onClaimReward: () => void;
  onShareGame: () => void;
  onSelectLevel: (levelId: string) => void;
  onOpenGenius: () => void;
  onOpenMinigames: () => void;
  onOpenMissions: () => void;
  onSwitchProfile: () => void;
  currentMapId: string;
  onSelectMap: (mapId: string) => void;
  musicEnabled: boolean;
  onToggleMusic: (enabled: boolean) => void;
  sfxEnabled: boolean;
  onToggleSfx: (enabled: boolean) => void;
}

export const ChildDashboard: React.FC<ChildDashboardProps> = ({ 
  profile, 
  rewardAvailable,
  onClaimReward,
  onShareGame,
  onSelectLevel, 
  onOpenGenius, 
  onOpenMinigames,
  onOpenMissions,
  onSwitchProfile,
  currentMapId,
  onSelectMap,
  musicEnabled,
  onToggleMusic,
  sfxEnabled,
  onToggleSfx
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const currentAvatar = AVATARS.find(a => a.id === profile.avatar) || AVATARS[0];
  const currentMap = MAPS.find(m => m.id === currentMapId) || MAPS[0];
  const mapLevels = LEVELS.filter(l => l.mapId === currentMapId).sort((a, b) => a.id.localeCompare(b.id));

  // Color logic...
  let mapContainerClass = '';
  let pathColor = '';
  let nodeColor = '';
  let islandColor = '';
  let waterGradient = '';
  let decorationEmoji = '';

  switch (currentMap.theme) {
    case 'birthday':
      mapContainerClass = 'bg-[#38bdf8]';
      waterGradient = 'radial-gradient(circle at 50% 50%, #67e8f9, #06b6d4 10px, transparent 11px, transparent 20px)';
      pathColor = 'stroke-[#ca8a04]';
      nodeColor = 'bg-yellow-100 border-yellow-500 text-yellow-800';
      islandColor = '#bef264';
      decorationEmoji = '🦜';
      break;
    case 'halloween':
      mapContainerClass = 'bg-[#2e1065]';
      waterGradient = 'radial-gradient(circle at 50% 50%, #4c1d95, #1e1b4b 10px, transparent 11px, transparent 20px)';
      pathColor = 'stroke-[#f97316]';
      nodeColor = 'bg-purple-100 border-purple-600 text-purple-900';
      islandColor = '#1e293b';
      decorationEmoji = '🎃';
      break;
    case 'christmas':
      mapContainerClass = 'bg-[#bfdbfe]';
      waterGradient = 'radial-gradient(circle at 50% 50%, #dbeafe, #60a5fa 10px, transparent 11px, transparent 20px)';
      pathColor = 'stroke-[#dc2626]';
      nodeColor = 'bg-red-50 border-red-600 text-red-800';
      islandColor = '#f0f9ff';
      decorationEmoji = '🎄';
      break;
    case 'summer':
      mapContainerClass = 'bg-[#0ea5e9]';
      waterGradient = 'radial-gradient(circle at 50% 50%, #bae6fd, #38bdf8 10px, transparent 11px, transparent 20px)';
      pathColor = 'stroke-[#d97706]';
      nodeColor = 'bg-orange-50 border-orange-500 text-orange-800';
      islandColor = '#fde047';
      decorationEmoji = '☀️';
      break;
  }

  const totalCompleted = profile.completedLevels.length;
  let rankTitle = "Grumete";
  if (totalCompleted > 5) rankTitle = "Marinero";
  if (totalCompleted > 10) rankTitle = "Navegante";
  if (totalCompleted > 15) rankTitle = "Capitán";
  if (totalCompleted >= 20) rankTitle = "Leyenda";

  return (
    <div className={`fixed inset-0 ${mapContainerClass} font-sans flex flex-col overflow-hidden transition-colors duration-700`}>
      
      <div className="relative z-50 bg-white/95 backdrop-blur-xl px-4 py-3 shadow-[0_4px_20px_rgba(0,0,0,0.1)] flex justify-between items-center border-b-4 border-black/5">
        <div className="flex items-center gap-3">
           <div className="relative group cursor-pointer" onClick={onSwitchProfile}>
              <div className="w-14 h-14 rounded-2xl overflow-hidden border-4 border-white shadow-lg bg-sky-100 transition-transform group-hover:scale-105">
                 <img src={currentAvatar.image} alt="Avatar" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-2 -right-2 bg-brand-DEFAULT text-white text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border-2 border-white shadow-sm">
                 {rankTitle}
              </div>
           </div>
           <div className="flex flex-col md:flex-row gap-1 md:gap-2">
               <div className="flex items-center gap-1.5 bg-orange-50 border-2 border-orange-200 px-2.5 py-1 rounded-xl shadow-sm">
                  <Flame size={18} className="text-orange-500 fill-orange-500 animate-pulse" />
                  <span className="font-black text-orange-700 text-sm">{profile.dailyStreak}</span>
               </div>
               <div className="flex items-center gap-1.5 bg-yellow-50 border-2 border-yellow-200 px-2.5 py-1 rounded-xl shadow-sm">
                  <CoinIcon size={18} />
                  <span className="font-black text-yellow-700 text-sm">{profile.stats.coins}</span>
               </div>
               <div className="flex items-center gap-1.5 bg-pink-50 border-2 border-pink-200 px-2.5 py-1 rounded-xl shadow-sm">
                  <Heart size={18} className="text-pink-500 fill-pink-500" />
                  <span className="font-black text-pink-700 text-sm">{profile.stats.happiness}%</span>
               </div>
           </div>
        </div>

        <div className="flex items-center gap-3">
           <button 
             onClick={onShareGame}
             className="bg-sky-400 hover:bg-sky-300 text-white px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-2 shadow-[0_4px_0_#0369a1] active:translate-y-1 active:shadow-none active:bg-sky-600 transition-all"
           >
             <Share2 size={16} /> 
             <span className="hidden md:inline">Compartir +20</span>
           </button>
           <button 
             onClick={() => setIsMenuOpen(true)}
             className="bg-slate-800 hover:bg-slate-700 text-white p-2 rounded-xl shadow-[0_4px_0_#0f172a] active:translate-y-1 active:shadow-none transition-all"
           >
             <Menu size={24} />
           </button>
        </div>
      </div>

      {/* TABS */}
      <div className="relative z-40 flex justify-center gap-3 pt-6 px-2 pb-4 overflow-x-auto scrollbar-hide">
         {MAPS.map(map => {
            const isUnlocked = profile.unlockedMaps.includes(map.id);
            const isActive = currentMapId === map.id;
            let activeColor = "bg-slate-400";
            if(map.theme === 'birthday') activeColor = "bg-emerald-500 border-emerald-700";
            if(map.theme === 'halloween') activeColor = "bg-purple-600 border-purple-800";
            if(map.theme === 'christmas') activeColor = "bg-rose-500 border-rose-700";
            if(map.theme === 'summer') activeColor = "bg-yellow-400 border-yellow-600 text-yellow-900";

            return (
               <button
                 key={map.id}
                 onClick={() => isUnlocked && onSelectMap(map.id)}
                 disabled={!isUnlocked}
                 className={`
                    px-4 py-2 rounded-2xl font-black text-xs md:text-sm flex items-center gap-2 transition-all shrink-0
                    ${isActive 
                        ? `${activeColor} text-white shadow-[0_4px_0_rgba(0,0,0,0.2)] scale-110 z-10 border-b-4` 
                        : isUnlocked 
                            ? "bg-white text-slate-500 border-2 border-transparent hover:bg-slate-50" 
                            : "bg-black/20 text-white/50 border-2 border-transparent cursor-not-allowed"
                    }
                 `}
               >
                 {!isUnlocked && <Lock size={12} />}
                 {map.name.split(' ')[0]} 
               </button>
            )
         })}
      </div>

      {/* MAP */}
      <div className="flex-1 relative w-full h-full overflow-hidden flex items-center justify-center p-4 pb-24">
         <div className="absolute inset-0 opacity-40 animate-pulse-slow" style={{ background: waterGradient }}></div>
         <div className="absolute top-1/4 left-10 text-5xl animate-float delay-700 opacity-90 drop-shadow-lg">{decorationEmoji}</div>
         <div className="absolute bottom-1/3 right-10 text-5xl animate-float delay-100 opacity-90 drop-shadow-lg">{currentMap.theme === 'summer' ? '🏖️' : decorationEmoji}</div>

         <div className="relative w-full max-w-md aspect-[3/4] drop-shadow-2xl transition-transform duration-500">
            <svg viewBox="0 0 300 400" className="w-full h-full overflow-visible">
                <defs>
                    <linearGradient id="islandGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor={islandColor} />
                        <stop offset="100%" stopColor={islandColor} stopOpacity="0.8" />
                    </linearGradient>
                </defs>
                <path d="M 30 100 Q 10 200 40 300 Q 100 380 200 350 Q 290 320 270 200 Q 250 50 150 30 Q 50 20 30 100 Z" fill="none" stroke="rgba(0,0,0,0.2)" strokeWidth="12" />
                <path d="M 30 100 Q 10 200 40 300 Q 100 380 200 350 Q 290 320 270 200 Q 250 50 150 30 Q 50 20 30 100 Z" fill={islandColor} stroke="none" className="drop-shadow-inner" />
                <path d="M 70 330 C 100 330, 100 280, 80 250 C 60 220, 100 200, 150 220 C 200 240, 220 280, 250 250 C 280 220, 200 180, 220 150 C 240 120, 180 100, 150 120 C 120 140, 80 100, 150 80" fill="none" className={`${pathColor} stroke-dashed`} strokeWidth="14" strokeLinecap="round" strokeDasharray="20 15" filter="drop-shadow(0px 2px 0px rgba(0,0,0,0.1))" />
            </svg>

            {mapLevels.length >= 7 && (
               <>
                <div className="absolute bottom-[15%] left-[18%]"><LevelNode level={mapLevels[0]} index={1} profile={profile} colorClass={nodeColor} onSelect={onSelectLevel} isStart /></div>
                <div className="absolute bottom-[35%] left-[22%]"><LevelNode level={mapLevels[1]} index={2} profile={profile} colorClass={nodeColor} onSelect={onSelectLevel} /></div>
                <div className="absolute bottom-[45%] left-[12%]"><LevelNode level={mapLevels[2]} index={3} profile={profile} colorClass={nodeColor} onSelect={onSelectLevel} /></div>
                <div className="absolute top-[45%] left-[45%]"><LevelNode level={mapLevels[3]} index={4} profile={profile} colorClass={nodeColor} onSelect={onSelectLevel} /></div>
                <div className="absolute bottom-[35%] right-[15%]"><LevelNode level={mapLevels[4]} index={5} profile={profile} colorClass={nodeColor} onSelect={onSelectLevel} /></div>
                <div className="absolute top-[35%] right-[20%]"><LevelNode level={mapLevels[5]} index={6} profile={profile} colorClass={nodeColor} onSelect={onSelectLevel} /></div>
                <div className="absolute top-[15%] left-[45%]"><LevelNode level={mapLevels[6]} index={7} profile={profile} colorClass={nodeColor} onSelect={onSelectLevel} isFinal /></div>
               </>
            )}
         </div>
      </div>

      {/* SIDE MENU */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-[100] flex justify-end">
           <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setIsMenuOpen(false)}></div>
           <div className="relative w-[85%] max-w-xs bg-[#f8fafc] h-full shadow-2xl p-6 animate-in slide-in-from-right duration-300 border-l-4 border-brand-light flex flex-col">
              
              <div className="flex justify-between items-center mb-6">
                  <h2 className="text-3xl font-display font-black text-slate-800">Menú</h2>
                  <button onClick={() => setIsMenuOpen(false)} className="bg-slate-200 p-2 rounded-full hover:bg-slate-300 text-slate-600">
                      <X size={24} />
                  </button>
              </div>

              <div className="space-y-3 flex-1 overflow-y-auto">
                  <div className="bg-slate-100 rounded-2xl p-4 mb-4">
                      <h3 className="text-xs font-bold text-slate-400 uppercase mb-3 tracking-wider">Configuración de Audio</h3>
                      <div className="flex justify-between items-center mb-3">
                          <div className="flex items-center gap-2 text-slate-700 font-bold">
                              <Music size={20} /> Música
                          </div>
                          <button 
                              onClick={() => onToggleMusic(!musicEnabled)}
                              className={`w-12 h-7 rounded-full p-1 transition-colors ${musicEnabled ? 'bg-green-500' : 'bg-slate-300'}`}
                          >
                              <div className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform ${musicEnabled ? 'translate-x-5' : 'translate-x-0'}`}></div>
                          </button>
                      </div>
                      <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2 text-slate-700 font-bold">
                              {sfxEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />} Efectos
                          </div>
                          <button 
                              onClick={() => onToggleSfx(!sfxEnabled)}
                              className={`w-12 h-7 rounded-full p-1 transition-colors ${sfxEnabled ? 'bg-green-500' : 'bg-slate-300'}`}
                          >
                              <div className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform ${sfxEnabled ? 'translate-x-5' : 'translate-x-0'}`}></div>
                          </button>
                      </div>
                  </div>

                  <button onClick={() => { setIsMenuOpen(false); onOpenMissions(); }} className="w-full bg-white border-2 border-indigo-100 hover:border-indigo-500 text-indigo-900 p-4 rounded-3xl flex items-center gap-4 shadow-sm hover:shadow-md active:scale-95 transition-all group">
                     <div className="bg-indigo-100 p-3 rounded-2xl text-indigo-600 group-hover:bg-indigo-500 group-hover:text-white transition-colors"><MapIcon size={28} /></div>
                     <div className="text-left"><div className="font-bold text-lg leading-none">Misiones</div><div className="text-xs opacity-60 font-bold mt-1 uppercase tracking-wider">Mapa Principal</div></div>
                  </button>

                  <button onClick={() => { setIsMenuOpen(false); onOpenMinigames(); }} className="w-full bg-white border-2 border-blue-100 hover:border-blue-500 text-blue-900 p-4 rounded-3xl flex items-center gap-4 shadow-sm hover:shadow-md active:scale-95 transition-all group">
                     <div className="bg-blue-100 p-3 rounded-2xl text-blue-600 group-hover:bg-blue-500 group-hover:text-white transition-colors"><Gamepad2 size={28} /></div>
                     <div className="text-left"><div className="font-bold text-lg leading-none">Minijuegos</div><div className="text-xs opacity-60 font-bold mt-1 uppercase tracking-wider">Gana Monedas</div></div>
                  </button>

                  <button onClick={() => { setIsMenuOpen(false); onOpenGenius(); }} className="w-full bg-white border-2 border-fuchsia-100 hover:border-fuchsia-500 text-fuchsia-900 p-4 rounded-3xl flex items-center gap-4 shadow-sm hover:shadow-md active:scale-95 transition-all group">
                     <div className="bg-fuchsia-100 p-3 rounded-2xl text-fuchsia-600 group-hover:bg-fuchsia-500 group-hover:text-white transition-colors"><Sparkles size={28} /></div>
                     <div className="text-left"><div className="font-bold text-lg leading-none">El Genio</div><div className="text-xs opacity-60 font-bold mt-1 uppercase tracking-wider">Ayuda IA</div></div>
                  </button>
              </div>

              <div className="mt-6">
                  <button onClick={onSwitchProfile} className="w-full border-2 border-slate-200 text-slate-400 font-bold py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-rose-50 hover:text-rose-500 hover:border-rose-200 transition-colors">
                      <LogOut size={20} /> SALIR
                  </button>
              </div>
           </div>
        </div>
      )}

      {rewardAvailable && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-md px-4">
            <div className="bg-white rounded-[2.5rem] p-8 text-center max-w-sm w-full shadow-2xl animate-bounce-in relative overflow-hidden border-4 border-white ring-4 ring-yellow-400/30">
                 <div className="absolute inset-0 bg-[radial-gradient(circle,var(--tw-gradient-stops))] from-yellow-50 to-transparent -z-10"></div>
                 <div className="text-7xl mb-4 animate-bounce drop-shadow-lg">🎁</div>
                 <h2 className="text-4xl font-display font-black text-slate-800 mb-2 tracking-tight">¡Regalo Diario!</h2>
                 <p className="text-slate-500 font-bold mb-6">¡Qué bueno verte de nuevo!</p>
                 <div className="flex justify-center items-center gap-6 mb-8 bg-yellow-50 p-6 rounded-3xl border-2 border-yellow-100">
                     <div className="flex flex-col items-center"><span className="text-5xl font-black text-amber-500 drop-shadow-sm">+{50 + (profile.dailyStreak * 10)}</span><div className="mt-1"><CoinIcon size={32} /></div></div>
                     <div className="w-0.5 h-12 bg-yellow-200"></div>
                     <div className="flex flex-col items-center"><span className="text-2xl font-black text-orange-500 flex items-center gap-1"><Flame size={24} fill="currentColor" /> {profile.dailyStreak}</span><span className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Días Racha</span></div>
                 </div>
                 <GameButton onClick={onClaimReward} variant="success" fullWidth className="shadow-lg text-xl py-5">¡RECOGER!</GameButton>
            </div>
        </div>
      )}
    </div>
  );
};

// Helper Component for Map Nodes
interface LevelNodeProps {
    level: LevelData;
    index: number;
    profile: ChildProfile;
    colorClass: string;
    onSelect: (id: string) => void;
    isStart?: boolean;
    isFinal?: boolean;
}

const LevelNode: React.FC<LevelNodeProps> = ({ level, index, profile, colorClass, onSelect, isStart, isFinal }) => {
    const levelNum = parseInt(level.id.split('_').pop() || '1'); 
    let prefix = level.id.substring(0, level.id.lastIndexOf('_')); 
    let prevId = `${prefix}_${levelNum - 1}`;
    const isUnlocked = levelNum === 1 || profile.completedLevels.includes(prevId);
    const isCompleted = profile.completedLevels.includes(level.id);

    return (
        <div className="relative flex flex-col items-center group z-10">
            <button onClick={() => isUnlocked && onSelect(level.id)} disabled={!isUnlocked} className={`w-14 h-14 md:w-16 md:h-16 rounded-2xl rotate-3 flex items-center justify-center border-b-[6px] border-x-2 border-t-2 shadow-lg transition-all duration-200 ${colorClass} ${!isUnlocked ? 'opacity-60 grayscale bg-slate-200 border-slate-300 cursor-not-allowed' : 'hover:scale-110 hover:-rotate-3 active:scale-95 cursor-pointer active:border-b-2 active:translate-y-1'} ${isCompleted ? '!bg-emerald-400 !border-emerald-600 text-white' : ''} ${!isCompleted && isUnlocked ? 'animate-bounce-in ring-4 ring-white/50' : ''}`}>
                {isCompleted ? <Check size={28} strokeWidth={4} /> : !isUnlocked ? <Lock size={22} className="text-slate-400" /> : <span className="font-display font-black text-2xl drop-shadow-sm">{index}</span>}
            </button>
            {isStart && <div className="absolute -top-8 bg-black text-white text-[10px] font-black px-3 py-1 rounded-lg uppercase tracking-widest shadow-lg animate-bounce">INICIO</div>}
            {isFinal && <div className="absolute -bottom-8 text-3xl drop-shadow-lg animate-wiggle">🏁</div>}
        </div>
    );
};
