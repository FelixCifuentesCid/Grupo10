import React, { useState, useEffect } from 'react';
import { ScreenName, User, UserRole, SavingsGoal, AVATARS, BICYCLE_GOAL_URL } from './types';
import MobileFrame from './components/MobileFrame';
import BottomNav from './components/BottomNav';
import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';
import StoryScene from './screens/StoryScene';
import ProfileScreen from './screens/ProfileScreen';
import MissionsScreen from './screens/MissionsScreen';
import PiggyBankScreen from './screens/PiggyBankScreen';
import ParentsPanelScreen from './screens/ParentsPanelScreen';
import CoinDropGameScreen from './screens/CoinDropGameScreen';

// Mock initial data if localStorage is empty
const getInitialUsers = (): User[] => {
  const storedUsers = localStorage.getItem('monedaventura_users');
  if (storedUsers) {
    try {
      const parsedUsers = JSON.parse(storedUsers);
      // Basic validation
      if (Array.isArray(parsedUsers) && parsedUsers.every(u => u.name && u.role && u.password)) {
        return parsedUsers;
      }
    } catch (e) {
      console.error("Failed to parse users from localStorage", e);
    }
  }
  // Default data if storage is empty or corrupt
  return [
    {
      name: 'Papá',
      role: 'parent',
      password: 'password1',
    },
    {
      name: 'Leo',
      role: 'child',
      password: '1234',
      avatarId: 'boy',
      coins: 150,
      stars: 25,
      trophies: 3,
      level: 2,
      goals: [
        { id: 'bike', name: 'Bicicleta Nueva', target: 500, current: 200 },
        { id: 'family_trip', name: 'Viaje Familiar', target: 2000, current: 800, isJoint: true },
      ],
      motivationalMessages: ["¡Sigue así, campeón! Estás haciendo un gran trabajo ahorrando."],
      completedMissions: ['b1', 'b2'],
    },
  ];
};


const App: React.FC = () => {
  const [users, setUsers] = useState<User[]>(getInitialUsers);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeScreen, setActiveScreen] = useState<ScreenName>('home');
  const [gameMode, setGameMode] = useState<'story' | 'coinDrop' | null>(null);
  const [currentMissionId, setCurrentMissionId] = useState<string | null>(null);


  // Persist users to localStorage
  useEffect(() => {
    localStorage.setItem('monedaventura_users', JSON.stringify(users));
  }, [users]);

  const handleSignUp = (name: string, role: UserRole, password: string): { success: boolean, message?: string } => {
    if (users.some(u => u.name.toLowerCase() === name.toLowerCase())) {
      return { success: false, message: 'Este nombre de usuario ya existe.' };
    }
    const newUser: User = {
      name,
      role,
      password,
      // Add default child properties if it's a child account
      ...(role === 'child' && {
        avatarId: 'boy',
        coins: 50,
        stars: 0,
        trophies: 0,
        level: 1,
        goals: [],
        motivationalMessages: [],
        completedMissions: [],
      })
    };
    setUsers(prevUsers => [...prevUsers, newUser]);
    // Automatically log in the new user
    setCurrentUser(newUser);
    if(newUser.role === 'child') {
        setActiveScreen('home');
    } else {
        setActiveScreen('parents');
    }
    return { success: true };
  };

  const handleLogin = (name: string, password: string): { success: boolean, message?: string } => {
    const user = users.find(u => u.name.toLowerCase() === name.toLowerCase() && u.password === password);
    if (user) {
      setCurrentUser(user);
      setActiveScreen(user.role === 'child' ? 'home' : 'parents');
      return { success: true };
    }
    return { success: false, message: 'Nombre de usuario o contraseña incorrectos.' };
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActiveScreen('login');
  };
  
  const handleNavigate = (screen: ScreenName) => {
    if (currentUser?.role === 'parent' && screen !== 'parents' && screen !== 'profile') {
        // For simplicity, parents can only access their panel and profile.
        return;
    }
    setActiveScreen(screen);
  };
  
  const handleUpdateUser = (updatedUser: User) => {
    setCurrentUser(updatedUser);
    setUsers(prevUsers => prevUsers.map(u => u.name === updatedUser.name ? updatedUser : u));
  };

  const handleUpdateChild = (updatedChild: User) => {
     setUsers(prevUsers => prevUsers.map(u => u.name === updatedChild.name ? updatedChild : u));
  };
  
  const handlePlayMission = (missionId: string) => {
      setCurrentMissionId(missionId);
      // Dummy logic to select a game type based on mission
      if (missionId.includes('2') || missionId.includes('6')) {
        setGameMode('story');
      } else {
        setGameMode('coinDrop');
      }
  };

  const handleFinishGame = (coinsEarned: number) => {
    if (currentUser && currentUser.role === 'child') {
        const updatedUser: User = {
            ...currentUser,
            coins: (currentUser.coins ?? 0) + coinsEarned,
            trophies: (currentUser.trophies ?? 0) + 1,
            completedMissions: Array.from(new Set([...(currentUser.completedMissions ?? []), currentMissionId!]))
        };
        handleUpdateUser(updatedUser);
    }
    setGameMode(null);
    setCurrentMissionId(null);
    setActiveScreen('missions');
  };

  if (!currentUser) {
    return (
        <MobileFrame bottomNav={null}>
            <LoginScreen onLogin={handleLogin} onSignUp={handleSignUp} />
        </MobileFrame>
    );
  }
  
  if (gameMode === 'story') {
      return (
          <MobileFrame bottomNav={null}>
              <StoryScene onFinish={handleFinishGame} />
          </MobileFrame>
      );
  }

  if (gameMode === 'coinDrop') {
      return (
          <MobileFrame bottomNav={null}>
              <CoinDropGameScreen onFinish={handleFinishGame} />
          </MobileFrame>
      );
  }

  const renderContent = () => {
    switch (activeScreen) {
      case 'home':
        return <HomeScreen 
                  user={currentUser} 
                  onStart={() => handleNavigate('missions')} 
                  onGoToParentsPanel={() => handleNavigate('parents')}
                  onGoToProfile={() => handleNavigate('profile')}
                />;
      case 'missions':
        return <MissionsScreen user={currentUser} onPlayMission={handlePlayMission} onNavigate={handleNavigate} />;
      case 'monedas':
        return <PiggyBankScreen user={currentUser} setUser={handleUpdateUser} />;
      case 'profile':
        return <ProfileScreen 
                    user={currentUser} 
                    setUser={handleUpdateUser} 
                    onGoToParentsPanel={() => handleNavigate('parents')}
                    onLogout={handleLogout}
                />;
      case 'parents':
        if (currentUser.role === 'parent') {
          const childUsers = users.filter(u => u.role === 'child');
          return <ParentsPanelScreen 
                    parentUser={currentUser} 
                    childUsers={childUsers}
                    onUpdateChild={handleUpdateChild}
                    onLogout={handleLogout}
                  />;
        }
        // Fallback for child trying to access parents panel directly (e.g., via a button on home)
        // A better approach might be to show a PIN screen.
        alert("Acceso restringido a padres.");
        setActiveScreen('home');
        return null;
      default:
        return <HomeScreen 
                  user={currentUser} 
                  onStart={() => handleNavigate('missions')} 
                  onGoToParentsPanel={() => handleNavigate('parents')}
                  onGoToProfile={() => handleNavigate('profile')}
                />;
    }
  };
  
  const bottomNav = currentUser.role === 'child' ? <BottomNav activeScreen={activeScreen} onNavigate={handleNavigate} /> : null;

  return (
    <MobileFrame bottomNav={bottomNav}>
      {renderContent()}
    </MobileFrame>
  );
};

export default App;