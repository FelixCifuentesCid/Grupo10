import React from 'react';
import { ScreenName } from '../types';
import { HomeIcon, MissionsIcon, CoinIcon, ProfileIcon } from './Icons';

interface BottomNavProps {
  activeScreen: ScreenName;
  onNavigate: (screen: ScreenName) => void;
}

const NavItem: React.FC<{
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
}> = ({ label, icon, isActive, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 transition-all duration-200 ${isActive ? 'text-blue-600 scale-110' : 'text-gray-400 hover:text-gray-600'}`}
    >
      <div className="w-7 h-7">{icon}</div>
      <span className={`text-xs font-bold ${isActive ? 'font-extrabold' : ''}`}>{label}</span>
    </button>
  );
};

const BottomNav: React.FC<BottomNavProps> = ({ activeScreen, onNavigate }) => {
  return (
    <div className="h-20 bg-white border-t-2 border-gray-100 flex justify-around items-center px-4 rounded-b-[36px]">
      <NavItem
        label="Inicio"
        icon={<HomeIcon />}
        isActive={activeScreen === 'home'}
        onClick={() => onNavigate('home')}
      />
      <NavItem
        label="Misiones"
        icon={<MissionsIcon />}
        isActive={activeScreen === 'missions'}
        onClick={() => onNavigate('missions')}
      />
      <NavItem
        label="Monedas"
        icon={<CoinIcon />}
        isActive={activeScreen === 'monedas'}
        onClick={() => onNavigate('monedas')}
      />
      <NavItem
        label="Perfil"
        icon={<ProfileIcon />}
        isActive={activeScreen === 'profile'}
        onClick={() => onNavigate('profile')}
      />
    </div>
  );
};

export default BottomNav;