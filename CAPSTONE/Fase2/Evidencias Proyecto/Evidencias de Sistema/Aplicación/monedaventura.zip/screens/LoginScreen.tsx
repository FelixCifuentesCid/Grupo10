import React, { useState, useEffect } from 'react';
import { UserRole } from '../types';
import { MONEDAVENTURA_LOGO_URL } from '../types';
import { EyeOpenIcon, EyeClosedIcon, ChildIcon, FamilyIcon } from '../components/Icons';

type View = 'login' | 'signup';

// REFACTOR: Simplified props for the new authentication flow.
interface LoginScreenProps {
  onLogin: (name: string, password: string) => { success: boolean; message?: string };
  onSignUp: (name: string, role: UserRole, password: string) => { success: boolean; message?: string };
}

const FloatingParticles: React.FC = () => {
    const particles = Array.from({ length: 15 });
    return (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {particles.map((_, i) => (
                <div
                    key={i}
                    className="absolute rounded-full bg-white/50 animate-particle-float"
                    style={{
                        top: `${Math.random() * 100}%`,
                        left: `${Math.random() * 100}%`,
                        width: `${Math.random() * 60 + 20}px`,
                        height: `${Math.random() * 60 + 20}px`,
                        animationDelay: `${Math.random() * 15}s`,
                        animationDuration: `${Math.random() * 15 + 10}s`,
                    }}
                />
            ))}
        </div>
    );
};

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onSignUp }) => {
  const [view, setView] = useState<View>('login');
  
  // Form fields
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [signupRole, setSignupRole] = useState<UserRole>('child');
  
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Reset form state when view changes
  useEffect(() => {
    setName('');
    setPassword('');
    setError('');
    setSuccessMessage('');
    setShowPassword(false);
    setSignupRole('child');
  }, [view]);

  const handleSignUpAttempt = () => {
    setError('');
    setSuccessMessage('');

    const passwordPattern = signupRole === 'child' ? /^\d{4}$/ : /^\d{6}$/;
    const passwordError = signupRole === 'child' 
      ? 'La contraseña debe ser de 4 números.' 
      : 'La contraseña debe ser de 6 números.';

    if (!name.trim()) {
      setError('⚠️ El nombre de usuario no puede estar vacío.');
      return;
    }
    if (!passwordPattern.test(password)) {
      setError(`⚠️ ${passwordError}`);
      return;
    }

    const result = onSignUp(name, signupRole, password);
    if (result.success) {
      setSuccessMessage('¡Usuario creado correctamente! ✅');
      // The App component will handle redirection.
    } else {
      setError(`⚠️ ${result.message || 'Ocurrió un error.'}`);
    }
  };
  
  const handleLoginAttempt = () => {
    setError('');
    setSuccessMessage('');

    if (!name || !password) {
      setError('⚠️ Debes completar tu nombre y contraseña.');
      return;
    }
    
    const result = onLogin(name, password);
    if (!result.success) {
      setError(`⚠️ ${result.message || 'Credenciales incorrectas.'}`);
    }
    // The App component will handle successful login and redirection.
  };

  const renderSignupForm = () => (
    <>
      <div className="mb-4">
        <label className="block text-gray-700 font-bold mb-2">Tipo de Usuario</label>
        <div className="flex gap-2">
            <button 
                onClick={() => setSignupRole('child')}
                className={`flex-1 p-3 rounded-full font-bold flex items-center justify-center gap-2 transition-all duration-200 border-2 ${signupRole === 'child' ? 'bg-yellow-400 text-gray-800 border-yellow-500 shadow-md' : 'bg-white text-gray-600 border-gray-200'}`}
            >
                <ChildIcon className="w-6 h-6" /> Niño/a
            </button>
            <button 
                onClick={() => setSignupRole('parent')}
                className={`flex-1 p-3 rounded-full font-bold flex items-center justify-center gap-2 transition-all duration-200 border-2 ${signupRole === 'parent' ? 'bg-green-600 text-white border-green-700 shadow-md' : 'bg-white text-gray-600 border-gray-200'}`}
            >
                <FamilyIcon className="w-6 h-6" /> Padre/Madre
            </button>
        </div>
      </div>
      <div className="space-y-3">
        <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Nombre de usuario" className="w-full px-4 py-3 text-gray-800 rounded-full border-2 border-gray-200 focus:outline-none focus:ring-2 focus:ring-yellow-400" />
        <div className="relative">
          <input 
            type={showPassword ? 'text' : 'password'} 
            value={password} 
            onChange={e => setPassword(e.target.value.replace(/\D/g, ''))} // Only allow digits
            placeholder={signupRole === 'child' ? 'Contraseña (4 números)' : 'Contraseña (6 números)'}
            maxLength={signupRole === 'child' ? 4 : 6}
            className="w-full pl-4 pr-10 py-3 text-gray-800 rounded-full border-2 border-gray-200 focus:outline-none focus:ring-2 focus:ring-yellow-400"
          />
          <button onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-3.5 text-gray-500">{showPassword ? <EyeClosedIcon className="w-5 h-5" /> : <EyeOpenIcon className="w-5 h-5" />}</button>
        </div>
      </div>
       <button 
          onClick={handleSignUpAttempt}
          className="w-full mt-4 bg-gradient-to-r from-blue-600 to-indigo-700 text-white font-extrabold text-xl py-3 rounded-full shadow-lg border-b-4 border-blue-800 transform transition-transform duration-150 hover:from-blue-700 hover:to-indigo-800 hover:scale-105 active:scale-100 active:border-b-2"
        >
          Crear Cuenta
        </button>
    </>
  );

  const renderLoginForm = () => (
    <>
      <div className="space-y-3">
          <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Nombre del usuario" className="w-full px-4 py-3 text-gray-800 rounded-full border-2 border-gray-200 focus:outline-none focus:ring-2 focus:ring-yellow-400" />
          <div className="relative">
              <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Contraseña" className="w-full pl-4 pr-10 py-3 text-gray-800 rounded-full border-2 border-gray-200 focus:outline-none focus:ring-2 focus:ring-yellow-400" />
              <button onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-3.5 text-gray-500">{showPassword ? <EyeClosedIcon className="w-5 h-5" /> : <EyeOpenIcon className="w-5 h-5" />}</button>
          </div>
      </div>
      <button 
        onClick={handleLoginAttempt}
        className="w-full mt-4 bg-gradient-to-r from-blue-600 to-indigo-700 text-white font-extrabold text-xl py-3 rounded-full shadow-lg border-b-4 border-blue-800 transform transition-transform duration-150 hover:from-blue-700 hover:to-indigo-800 hover:scale-105 active:scale-100 active:border-b-2"
      >
        Ingresar 🪙
      </button>
    </>
  );
  
  return (
    <>
      <style>{`
        @keyframes subtle-bounce { 0%, 100% { transform: translateY(0) rotate(-5deg); } 50% { transform: translateY(-10px) rotate(5deg); } }
        .animate-fox-bounce { animation: subtle-bounce 3s ease-in-out infinite; }
        @keyframes error-shake { 0%, 100% { transform: translateX(0); } 10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); } 20%, 40%, 60%, 80% { transform: translateX(5px); } }
        .animate-error-shake { animation: error-shake 0.5s ease-in-out; }
        @keyframes particle-float {
            0% { transform: translateY(100vh) scale(0.5); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100vh) scale(1); opacity: 0; }
        }
        .animate-particle-float { animation: particle-float linear infinite; }
      `}</style>
      <div className="flex flex-col items-center justify-center h-full p-4 bg-gradient-to-br from-sky-200 to-green-200 text-center text-gray-800 overflow-hidden relative">
        <FloatingParticles />

        <img src={MONEDAVENTURA_LOGO_URL} alt="Monedaventura Logo" className="w-48 mb-2 animate-fox-bounce z-10" />
        <p className="font-bold mt-1 mb-4 z-10">
            {view === 'signup' ? '¡Hola pequeño explorador del ahorro! 🪙✨' : '¡Qué bueno verte de nuevo! 👋'}
        </p>

        <div className="w-full max-w-xs bg-white/60 backdrop-blur-md p-4 rounded-3xl shadow-lg z-10">
          <div className="flex bg-gray-200/80 rounded-full p-1 mb-4">
            <button onClick={() => setView('login')} className={`w-1/2 py-2 rounded-full font-bold transition-colors ${view === 'login' ? 'bg-white text-gray-800 shadow' : 'text-gray-500'}`}>Ingresar</button>
            <button onClick={() => setView('signup')} className={`w-1/2 py-2 rounded-full font-bold transition-colors ${view === 'signup' ? 'bg-white text-gray-800 shadow' : 'text-gray-500'}`}>Crear Cuenta</button>
          </div>
          
          {view === 'login' ? renderLoginForm() : renderSignupForm()}

          {error && <p className="text-red-900 bg-red-300/80 px-3 py-2 mt-3 rounded-lg text-sm font-bold animate-error-shake">{error}</p>}
          {successMessage && <p className="text-green-900 bg-green-200/80 px-3 py-2 mt-3 rounded-lg text-sm font-bold">{successMessage}</p>}
        </div>
      </div>
    </>
  );
};

export default LoginScreen;