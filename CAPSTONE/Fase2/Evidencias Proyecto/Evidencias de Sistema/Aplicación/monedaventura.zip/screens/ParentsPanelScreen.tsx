import React, { useState } from 'react';
import { User, SavingsGoal, AVATARS } from '../types';
import { CoinIcon, PlusIcon } from '../components/Icons';
import ProgressModal from '../components/ProgressModal';

interface ChildManagerProps {
  child: User;
  onUpdate: (updatedChild: User) => void;
  onShowProgress: () => void;
}

const ChildManager: React.FC<ChildManagerProps> = ({ child, onUpdate, onShowProgress }) => {
  const [message, setMessage] = useState('');
  const [coins, setCoins] = useState('');
  const [goalName, setGoalName] = useState('');
  const [goalTarget, setGoalTarget] = useState('');

  const childAvatarUrl = child.customAvatarUrl || AVATARS[child.avatarId ?? 'boy'].image;

  const handleSendMessage = () => {
    if (!message.trim()) return;
    const updatedChild = {
      ...child,
      motivationalMessages: [...(child.motivationalMessages ?? []), message],
    };
    onUpdate(updatedChild);
    setMessage('');
  };

  const handleAddCoins = () => {
    const amount = parseInt(coins, 10);
    if (isNaN(amount)) return;
    const updatedChild = { ...child, coins: (child.coins ?? 0) + amount };
    onUpdate(updatedChild);
    setCoins('');
  };

  const handleAddGoal = () => {
    const target = parseInt(goalTarget, 10);
    if (!goalName.trim() || isNaN(target) || target <= 0) return;
    const newGoal: SavingsGoal = {
      id: `goal_family_${Date.now()}`,
      name: goalName,
      target,
      current: 0,
      isJoint: true,
    };
    const updatedChild = { ...child, goals: [...(child.goals ?? []), newGoal] };
    onUpdate(updatedChild);
    setGoalName('');
    setGoalTarget('');
  };
  
  return (
    <div className="bg-white p-4 rounded-2xl shadow-lg space-y-4 animate-fade-in">
        <div className="flex items-center gap-3 border-b pb-3">
            <img src={childAvatarUrl} alt={child.name} className="w-16 h-16 rounded-full border-4 border-blue-200 object-cover" />
            <div>
                <h3 className="text-xl font-black text-gray-800">{child.name}</h3>
                <div className="flex items-center gap-2 text-yellow-600 font-bold">
                    <CoinIcon className="w-5 h-5" />
                    <span>{child.coins ?? 0} Monedas</span>
                </div>
            </div>
        </div>
        
        {/* Send Message */}
        <div>
            <h4 className="font-bold text-gray-700 mb-1">Enviar mensaje motivacional 💌</h4>
            <div className="flex gap-2">
                <input type="text" value={message} onChange={e => setMessage(e.target.value)} placeholder="¡Buen trabajo!" className="flex-grow p-2 border rounded-lg" />
                <button onClick={handleSendMessage} className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 rounded-lg font-bold shadow-sm hover:from-blue-600 hover:to-blue-700 active:scale-95 transition-all">Enviar</button>
            </div>
        </div>

        {/* Add Coins */}
        <div>
            <h4 className="font-bold text-gray-700 mb-1">Añadir/Quitar Monedas 💰</h4>
            <div className="flex gap-2">
                <input type="number" value={coins} onChange={e => setCoins(e.target.value)} placeholder="Ej: 50 o -10" className="flex-grow p-2 border rounded-lg" />
                <button onClick={handleAddCoins} className="bg-gradient-to-r from-green-500 to-green-600 text-white px-4 rounded-lg font-bold shadow-sm hover:from-green-600 hover:to-green-700 active:scale-95 transition-all">Ajustar</button>
            </div>
        </div>
        
        {/* Add Goal */}
        <div>
            <h4 className="font-bold text-gray-700 mb-1">Crear Meta Familiar 🎯</h4>
            <div className="space-y-2">
                <input type="text" value={goalName} onChange={e => setGoalName(e.target.value)} placeholder="Nombre de la meta" className="w-full p-2 border rounded-lg" />
                <input type="number" value={goalTarget} onChange={e => setGoalTarget(e.target.value)} placeholder="Monedas necesarias" className="w-full p-2 border rounded-lg" />
                <button onClick={handleAddGoal} className="w-full bg-gradient-to-r from-cyan-500 to-cyan-600 text-white p-2 rounded-lg font-bold shadow-sm hover:from-cyan-600 hover:to-cyan-700 active:scale-95 transition-all">Crear Meta</button>
            </div>
        </div>
         <button onClick={onShowProgress} className="w-full bg-gradient-to-r from-purple-500 to-indigo-600 text-white p-3 rounded-lg font-bold shadow-md hover:from-purple-600 hover:to-indigo-700 active:scale-95 transition-all">
            Ver Progreso Detallado
        </button>
    </div>
  );
};

interface ParentsPanelScreenProps {
  parentUser: User;
  childUsers: User[];
  onUpdateChild: (updatedChild: User) => void;
  onLogout: () => void;
}

const ParentsPanelScreen: React.FC<ParentsPanelScreenProps> = ({ parentUser, childUsers, onUpdateChild, onLogout }) => {
  const [selectedChild, setSelectedChild] = useState<User | null>(childUsers[0] ?? null);
  const [progressChild, setProgressChild] = useState<User | null>(null);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const handleLogout = () => {
    setIsLoggingOut(true);
    setTimeout(() => {
        onLogout();
    }, 1500); // Wait for animation to finish
  };

  return (
    <>
    <style>{`
        @keyframes fade-in {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fade-in 0.5s ease-out forwards;
        }
        @keyframes goodbye-fade {
            0% { opacity: 0; }
            50% { opacity: 1; }
            100% { opacity: 0; }
        }
        .animate-goodbye-fade {
            animation: goodbye-fade 1.5s ease-in-out forwards;
        }
        @keyframes wave {
              0% { transform: rotate(0.0deg) }
              10% { transform: rotate(14.0deg) }
              20% { transform: rotate(-8.0deg) }
              30% { transform: rotate(14.0deg) }
              40% { transform: rotate(-4.0deg) }
              50% { transform: rotate(10.0deg) }
              60% { transform: rotate(0.0deg) }
              100% { transform: rotate(0.0deg) }
        }
        .animate-wave {
              animation: wave 2.5s ease-in-out infinite;
              transform-origin: 70% 70%;
              display: inline-block;
        }
    `}</style>
    <div className="h-full bg-gradient-to-b from-blue-100 to-green-100 p-4 overflow-y-auto">
      {isLoggingOut && (
         <div className="absolute inset-0 bg-gradient-to-b from-blue-100 to-green-100 flex flex-col items-center justify-center z-50 animate-goodbye-fade">
            <p className="text-6xl animate-wave">👋</p>
            <h2 className="text-3xl font-black text-gray-700 mt-4">¡Hasta pronto!</h2>
        </div>
      )}
      {progressChild && <ProgressModal user={progressChild} userRole="parent" onClose={() => setProgressChild(null)} />}
      <header className="flex justify-between items-center mb-4">
        <div>
          <h1 className="text-3xl font-black text-gray-800">Panel de Padres</h1>
          <p className="text-gray-600 font-semibold">Bienvenido/a, {parentUser.name}!</p>
        </div>
        <button onClick={handleLogout} className="bg-red-500 text-white font-bold py-2 px-4 rounded-full shadow-md transition-transform active:scale-95">Salir</button>
      </header>
      
      <section className="mb-6">
        <h2 className="font-bold text-lg text-gray-700 mb-2">Selecciona un hijo/a:</h2>
        <div className="flex flex-wrap gap-2">
          {childUsers.map(child => {
            const childAvatarUrl = child.customAvatarUrl || AVATARS[child.avatarId ?? 'boy'].image;
            return (
                <button
                key={child.name}
                onClick={() => setSelectedChild(child)}
                className={`flex items-center gap-2 p-2 rounded-full transition-all duration-200 ${selectedChild?.name === child.name ? 'bg-blue-500 text-white shadow-lg' : 'bg-white text-gray-700 shadow-sm'}`}
                >
                <img src={childAvatarUrl} alt={child.name} className="w-8 h-8 rounded-full object-cover" />
                <span className="font-bold">{child.name}</span>
                </button>
            )
          })}
          {childUsers.length === 0 && <p className="text-gray-500">No hay perfiles de hijos/as. Crea una cuenta para empezar.</p>}
        </div>
      </section>
      
      <section>
        {selectedChild ? (
          <ChildManager 
            child={selectedChild} 
            onUpdate={onUpdateChild} 
            onShowProgress={() => setProgressChild(selectedChild)}
          />
        ) : (
          <div className="text-center p-8 bg-white/50 rounded-2xl">
            <p className="font-bold text-gray-600">Selecciona un perfil para ver su progreso y administrar sus finanzas. 🚀</p>
          </div>
        )}
      </section>
    </div>
    </>
  );
};

export default ParentsPanelScreen;