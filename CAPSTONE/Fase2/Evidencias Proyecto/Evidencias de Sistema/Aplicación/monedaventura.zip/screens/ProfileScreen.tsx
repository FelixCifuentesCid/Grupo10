import React, { useState, useRef } from 'react';
import { User, AVATARS, AvatarId, STAR_FLOAT_URL, ScreenName } from '../types';
import { StarIcon, CoinIcon, TrophyIcon, CameraIcon } from '../components/Icons';

interface ProfileScreenProps {
  user: User;
  setUser: (user: User) => void;
  onGoToParentsPanel: () => void;
  onLogout: () => void;
}

const StatDisplay: React.FC<{ value: number; label: string; icon: React.ReactNode }> = ({ value, label, icon }) => (
    <div className="flex flex-col items-center">
        <div className="p-3 bg-white rounded-full mb-1">{icon}</div>
        <span className="font-black text-xl text-gray-700">{value}</span>
        <span className="text-xs font-bold text-gray-500">{label}</span>
    </div>
);


const ProfileScreen: React.FC<ProfileScreenProps> = ({ user, setUser, onGoToParentsPanel, onLogout }) => {
    const [selectedAvatar, setSelectedAvatar] = useState<AvatarId>(user.avatarId ?? 'boy');
    const [customAvatarPreview, setCustomAvatarPreview] = useState<string | null>(user.customAvatarUrl || null);
    const [isEditing, setIsEditing] = useState(false);
    const [justSaved, setJustSaved] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setCustomAvatarPreview(reader.result as string);
                // Deselect predefined avatar when custom is chosen
                setSelectedAvatar('boy'); 
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleSelectPredefined = (id: AvatarId) => {
        setSelectedAvatar(id);
        setCustomAvatarPreview(null);
    };

    const handleSave = () => {
        const updatedUser = {
            ...user,
            avatarId: selectedAvatar,
            customAvatarUrl: customAvatarPreview || undefined,
        };
        setUser(updatedUser);
        setIsEditing(false);
        setJustSaved(true);
        setTimeout(() => setJustSaved(false), 1200);
    };
    
    const handleCancel = () => {
        // Reset changes to original state
        setSelectedAvatar(user.avatarId ?? 'boy');
        setCustomAvatarPreview(user.customAvatarUrl || null);
        setIsEditing(false);
    };
    
    const avatarUrl = user.customAvatarUrl || AVATARS[user.avatarId ?? 'boy'].image;
    const editingAvatarUrl = customAvatarPreview || AVATARS[selectedAvatar ?? 'boy'].image;

    if (isEditing) {
        return (
            <div className="p-6 bg-[#E8F5E1] h-full flex flex-col animate-fadeIn">
                 <input type="file" accept="image/*" ref={fileInputRef} onChange={handleImageUpload} className="hidden" />
                <h1 className="text-3xl font-black text-gray-800 text-center mb-6">Elige tu Avatar ✨</h1>
                <div className="grid grid-cols-2 gap-4 flex-grow content-start">
                    {/* Upload Button */}
                    <button
                        onClick={() => fileInputRef.current?.click()}
                        className={`avatar-button p-3 rounded-2xl flex flex-col items-center justify-center transition-all duration-200 transform ${customAvatarPreview ? 'bg-yellow-300 shadow-xl scale-105' : 'bg-white shadow-md hover:shadow-lg hover:scale-105'}`}
                    >
                         <div className="bg-[#DDF4C8] rounded-xl w-full aspect-square flex items-center justify-center">
                            {customAvatarPreview ? (
                                <img src={customAvatarPreview} alt="Preview" className="w-full h-full object-cover rounded-lg" />
                            ) : (
                                <CameraIcon className="w-12 h-12 text-gray-400" />
                            )}
                        </div>
                        <p className="mt-2 font-bold text-gray-700">Subir foto</p>
                    </button>
                    {/* Predefined Avatars */}
                    {Object.entries(AVATARS).map(([id, avatar]) => (
                        <button
                            key={id}
                            onClick={() => handleSelectPredefined(id as AvatarId)}
                            className={`avatar-button p-3 rounded-2xl transition-all duration-200 transform ${!customAvatarPreview && selectedAvatar === id ? 'bg-yellow-300 shadow-xl scale-105' : 'bg-white shadow-md hover:shadow-lg hover:scale-105'}`}
                        >
                            <div className="bg-[#DDF4C8] rounded-xl">
                                <img src={avatar.image} alt={avatar.name} className="w-full h-auto rounded-lg" />
                            </div>
                            <p className="mt-2 font-bold text-gray-700">{avatar.name}</p>
                        </button>
                    ))}
                </div>
                <div className="mt-auto pt-6 flex flex-col gap-2">
                     <button onClick={handleSave} className="w-full bg-[#96D850] text-white font-extrabold text-lg py-3 rounded-full shadow-lg border-b-4 border-green-600 transition-transform duration-150 active:scale-95 active:border-b-2">
                        Guardar ✅
                    </button>
                    <button onClick={handleCancel} className="w-full text-gray-500 font-bold py-2 transition-transform duration-150 active:scale-95">
                        Cancelar ❌
                    </button>
                </div>
                 <style>{`
                    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
                    .animate-fadeIn { animation: fadeIn 0.4s ease-out forwards; }
                    @keyframes selectionPop { 0% { transform: scale(1); } 50% { transform: scale(1.1) rotate(-3deg); } 100% { transform: scale(1); } }
                    .avatar-button:active { animation: selectionPop 0.3s ease-in-out; }
                `}</style>
            </div>
        );
    }

    return (
        <>
            <style>{`
                @keyframes subtleBounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
                .animate-subtle-bounce { animation: subtleBounce 2.5s ease-in-out infinite; }
                @keyframes float-profile { 0% { transform: translatey(0px) scale(0.9); opacity: 0.8; } 50% { transform: translatey(-15px) scale(1); opacity: 1; } 100% { transform: translatey(0px) scale(0.9); opacity: 0.8; } }
                .animate-float-profile-1 { animation: float-profile 4s ease-in-out infinite; }
                .animate-float-profile-2 { animation: float-profile 5s ease-in-out infinite; animation-delay: 1.5s; }
                @keyframes saved-glow {
                    0% { box-shadow: 0 0 0px 0px rgba(253, 224, 71, 0.7); }
                    50% { box-shadow: 0 0 25px 8px rgba(253, 224, 71, 0.7); }
                    100% { box-shadow: 0 0 0px 0px rgba(253, 224, 71, 0); }
                }
                .animate-saved-glow { animation: saved-glow 1.2s ease-out; }
            `}</style>
            <div className="h-full flex flex-col bg-gradient-to-b from-lime-50 to-yellow-50 relative overflow-hidden">
                <div className="bg-[#96D850] h-48 rounded-b-[40px] flex flex-col items-center p-6 relative">
                    <h1 className="text-2xl font-black text-white" style={{textShadow: '1px 1px 2px rgba(0,0,0,0.2)'}}>Perfil</h1>
                    <div className="absolute top-28 animate-subtle-bounce z-10">
                        <div className={`w-32 h-32 rounded-full bg-white p-2 shadow-lg ${justSaved ? 'animate-saved-glow' : ''}`}>
                            <img 
                                src={avatarUrl} 
                                alt={user.name} 
                                className="w-full h-full rounded-full object-cover"
                            />
                        </div>
                    </div>
                </div>
                
                <div className="flex-grow pt-20 text-center">
                    <h2 className="text-3xl font-black text-gray-800">{user.name}</h2>
                    <p className="text-gray-500 font-bold">Nivel {user.level ?? 1} - Aventurero</p>
                     <p className="text-amber-600 font-semibold mt-1 text-sm">
                        ¡{AVATARS[user.avatarId ?? 'boy'].name} te acompaña en esta aventura! 🌟💰
                    </p>
                    
                    <div className="px-6 mt-4">
                        <div className="grid grid-cols-3 gap-4 bg-white/60 backdrop-blur-sm p-4 rounded-2xl shadow-md">
                            <StatDisplay value={user.stars ?? 0} label="Estrellas" icon={<StarIcon className="w-6 h-6 text-yellow-400"/>} />
                            <StatDisplay value={user.coins ?? 0} label="Monedas" icon={<CoinIcon className="w-6 h-6 text-yellow-500"/>} />
                            <StatDisplay value={user.trophies ?? 0} label="Misiones" icon={<TrophyIcon className="w-6 h-6 text-orange-400"/>} />
                        </div>
                    </div>

                    <div className="px-6 mt-6 space-y-3">
                        <button
                            onClick={() => setIsEditing(true)}
                            className="w-full bg-[#FDD201] text-gray-800 font-extrabold text-lg py-3 rounded-full shadow-lg border-b-4 border-[#E9B800] transform transition-transform duration-150 hover:scale-105 active:scale-95 active:border-b-2"
                        >
                            Cambiar Avatar 🎨
                        </button>
                        <button
                            onClick={onLogout}
                            className="w-full bg-red-500 text-white font-extrabold text-lg py-3 rounded-full shadow-lg border-b-4 border-red-700 transform transition-transform duration-150 hover:scale-105 active:scale-95 active:border-b-2"
                        >
                            Cerrar sesión 🚪
                        </button>
                    </div>
                </div>
                
                {/* Decorative floating elements */}
                <img src={STAR_FLOAT_URL} className="absolute w-10 top-1/2 left-4 animate-float-profile-1 pointer-events-none opacity-50" alt="Star" />
                <img src={STAR_FLOAT_URL} className="absolute w-16 top-3/4 right-[-2rem] animate-float-profile-2 pointer-events-none opacity-50" alt="Star" />

            </div>
        </>
    );
};

export default ProfileScreen;