import React, { useState, useEffect } from 'react';
import { User, SavingsGoal, PIGGY_BANK_URL, AVATARS, TREASURE_CHEST_URL } from '../types';
import { CoinIcon } from '../components/Icons';

interface PiggyBankScreenProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User>>;
}

const GoalCard: React.FC<{ goal: SavingsGoal; onAdd: (amount: number) => void; onWithdraw: (amount: number) => void; userCoins: number; }> = ({ goal, onAdd, onWithdraw, userCoins }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const progress = Math.min((goal.current / goal.target) * 100, 100);
  const addAmount = 10;
  
  return (
    <div className="bg-white p-4 rounded-2xl shadow-md w-full">
      <div className="flex justify-between items-start">
        <div className="flex items-center gap-2 flex-wrap">
          <h3 className="font-extrabold text-gray-800 text-lg">{goal.name}</h3>
          {goal.isJoint && <span className="text-xs bg-cyan-100 text-cyan-700 font-bold px-2 py-0.5 rounded-full" title="Meta Conjunta">FAMILIA 👨‍👩‍👧</span>}
        </div>
        <div className="flex items-center gap-2">
            <button
                onClick={() => onWithdraw(addAmount)}
                disabled={goal.current < addAmount}
                className="w-8 h-8 bg-gray-200 text-gray-600 rounded-full font-bold text-xl flex items-center justify-center disabled:opacity-50 transition-transform active:scale-90"
            >−</button>
            <button
                onClick={() => onAdd(addAmount)}
                disabled={userCoins < addAmount}
                className="w-8 h-8 bg-green-400 text-white rounded-full font-bold text-xl flex items-center justify-center disabled:opacity-50 transition-transform active:scale-90"
            >+</button>
        </div>
      </div>
       <p className="font-bold text-gray-500 text-sm mt-1">
            {goal.current} / {goal.target} monedas
        </p>
      <div className="w-full bg-gray-200 rounded-full h-4 mt-2">
        <div 
          className="bg-gradient-to-r from-yellow-300 to-yellow-500 h-4 rounded-full flex items-center justify-end text-white pr-2 text-xs font-bold transition-all duration-1000 ease-out" 
          style={{ width: isLoaded ? `${progress}%` : '0%' }}
        >
          {Math.round(progress)}%
        </div>
      </div>
    </div>
  );
};

const AddGoalModal: React.FC<{ onSave: (name: string, target: number) => void; onClose: () => void; }> = ({ onSave, onClose }) => {
    const [name, setName] = useState('');
    const [target, setTarget] = useState('');

    const handleSave = () => {
        const targetAmount = parseInt(target, 10);
        if (name.trim() && !isNaN(targetAmount) && targetAmount > 0) {
            onSave(name.trim(), targetAmount);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl p-6 w-full max-w-sm animate-modal-in">
                <h2 className="text-2xl font-black text-gray-800 text-center mb-4">Nueva Meta de Ahorro 🎯</h2>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="goal-name" className="text-sm font-bold text-gray-600">Nombre de la meta</label>
                        <input
                            id="goal-name"
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="Ej: Videojuego nuevo"
                            className="w-full mt-1 p-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                        />
                    </div>
                    <div>
                        <label htmlFor="goal-target" className="text-sm font-bold text-gray-600">¿Cuántas monedas necesitas?</label>
                        <input
                            id="goal-target"
                            type="number"
                            value={target}
                            onChange={(e) => setTarget(e.target.value)}
                            placeholder="Ej: 500"
                            className="w-full mt-1 p-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400"
                        />
                    </div>
                </div>
                <div className="mt-6 flex flex-col gap-2">
                    <button onClick={handleSave} className="w-full bg-[#96D850] text-white font-extrabold text-lg py-3 rounded-full shadow-lg border-b-4 border-green-600 active:border-b-2">
                        Crear Meta 🚀
                    </button>
                    <button onClick={onClose} className="w-full text-gray-500 font-bold py-2">
                        Cancelar
                    </button>
                </div>
            </div>
             <style>{`
                @keyframes modal-in {
                    from { opacity: 0; transform: scale(0.9); }
                    to { opacity: 1; transform: scale(1); }
                }
                .animate-modal-in {
                    animation: modal-in 0.3s ease-out;
                }
            `}</style>
        </div>
    );
};


const PiggyBankScreen: React.FC<PiggyBankScreenProps> = ({ user, setUser }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const userCoins = user.coins ?? 0;
  const userGoals = user.goals ?? [];
  const [displayedCoins, setDisplayedCoins] = useState(userCoins);

  useEffect(() => {
    const animationDuration = 500; // ms
    const frameDuration = 1000 / 60; // 60fps
    const diff = userCoins - displayedCoins;
    if (diff === 0) return;

    const totalFrames = Math.round(animationDuration / frameDuration);
    let frame = 0;

    const counter = setInterval(() => {
        frame++;
        const progress = frame / totalFrames;
        const currentCount = displayedCoins + diff * progress;
        setDisplayedCoins(Math.round(currentCount));

        if (frame === totalFrames) {
            clearInterval(counter);
            setDisplayedCoins(userCoins); // Ensure it ends on the exact number
        }
    }, frameDuration);

    return () => clearInterval(counter);
  }, [userCoins, displayedCoins]);


  const handleAddGoal = (name: string, target: number) => {
    const newGoal: SavingsGoal = {
      id: `goal_${Date.now()}`,
      name,
      target,
      current: 0,
    };
    setUser(prevUser => ({
      ...prevUser,
      goals: [...(prevUser.goals ?? []), newGoal],
    }));
    setIsModalOpen(false);
  };

  const handleUpdateGoal = (goalId: string, amount: number) => {
    setUser(prevUser => {
        if (!prevUser) return prevUser;
        const currentGoals = prevUser.goals ?? [];
        const currentCoins = prevUser.coins ?? 0;

        const newGoals = currentGoals.map(goal => {
            if (goal.id === goalId) {
                return { ...goal, current: Math.max(0, goal.current + amount) };
            }
            return goal;
        });
        return {
            ...prevUser,
            coins: currentCoins - amount,
            goals: newGoals,
        };
    });
  };

  return (
    <>
      <style>{`
          @keyframes subtleBounce {
              0%, 100% { transform: translateY(0); }
              50% { transform: translateY(-6px); }
          }
          .animate-piggy-bounce {
              animation: subtleBounce 3s ease-in-out infinite;
          }
          .coin-pattern {
            background-image: radial-gradient(circle, rgba(250, 204, 21, 0.2) 1px, transparent 1px);
            background-size: 20px 20px;
          }
           @keyframes float {
            0% { transform: translatey(0px) rotate(-5deg); }
            50% { transform: translatey(-15px) rotate(5deg); }
            100% { transform: translatey(0px) rotate(-5deg); }
          }
          .animate-float-chest { animation: float 5s ease-in-out infinite; }
      `}</style>
      <div className="w-full min-h-full bg-gradient-to-b from-[#FFF9C4] to-[#FFE082] p-4 pb-24 coin-pattern relative overflow-hidden">
        {isModalOpen && <AddGoalModal onSave={handleAddGoal} onClose={() => setIsModalOpen(false)} />}
        
        <img src={TREASURE_CHEST_URL} className="absolute w-32 -top-4 -right-8 animate-float-chest pointer-events-none opacity-80" alt="Treasure Chest" />

        <header className="text-center mb-6">
          <h1 className="text-3xl font-black text-gray-800">Mi Alcancía 🐷💰</h1>
          <p className="text-gray-500 font-bold">¡Cada moneda cuenta para tus sueños! ✨</p>
        </header>

        <div className="flex flex-col items-center gap-4 mb-8">
          <img src={PIGGY_BANK_URL} alt="Alcancía" className="w-40 h-40 animate-piggy-bounce" />
          <div className="bg-white shadow-lg p-3 rounded-full flex items-center gap-3">
            <div className="bg-yellow-100 p-2 rounded-full">
              <CoinIcon className="w-8 h-8 text-yellow-500" />
            </div>
            <div>
              <p className="text-sm font-bold text-gray-500">Total de Monedas</p>
              <p className="text-2xl font-black text-gray-800">{displayedCoins}</p>
            </div>
          </div>
        </div>

        <section>
          <div className="flex justify-between items-end mb-3 px-2">
            <h2 className="font-extrabold text-xl text-gray-700">Mis Metas de Ahorro</h2>
            <img src={AVATARS.owl.image} alt="Búho Sabio" className="w-20" />
          </div>
          <div className="space-y-3">
            {userGoals.length > 0 ? (
              userGoals.map(goal => <GoalCard key={goal.id} goal={goal} onAdd={(amount) => handleUpdateGoal(goal.id, amount)} onWithdraw={(amount) => handleUpdateGoal(goal.id, -amount)} userCoins={userCoins} />)
            ) : (
              <div className="bg-white/70 text-center p-6 rounded-2xl border-2 border-dashed border-gray-300">
                <p className="font-bold text-gray-600">¡Aún no tienes metas! 🤔</p>
                <p className="text-sm text-gray-500">Crea una meta para empezar a ahorrar para algo especial. ✨</p>
              </div>
            )}
          </div>
        </section>
        
        <div className="mt-8">
          <button
              onClick={() => setIsModalOpen(true)}
              className="w-full bg-[#FDD201] text-gray-800 font-extrabold text-lg py-3 rounded-full shadow-lg border-b-4 border-[#E9B800] transform transition-transform duration-150 hover:scale-105 active:scale-100 active:border-b-2"
          >
              Crear Nueva Meta ➕
          </button>
        </div>

      </div>
    </>
  );
};

export default PiggyBankScreen;
