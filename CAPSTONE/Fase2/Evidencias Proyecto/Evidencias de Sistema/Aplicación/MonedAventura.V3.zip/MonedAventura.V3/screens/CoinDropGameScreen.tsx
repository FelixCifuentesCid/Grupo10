import React, { useState, useEffect, useCallback, useRef } from 'react';
import { COIN_GAME_URL } from '../types';

interface Coin {
  id: number;
  left: number;
  duration: number;
  delay: number;
  caught: boolean;
}

interface Difficulty {
  name: string;
  duration: number;
  spawnRate: number; // ms between spawns
  minFallSpeed: number; // seconds
  maxFallSpeed: number; // seconds
  color: string;
  borderColor: string;
}

const difficulties: Record<string, Difficulty> = {
  easy: { name: 'Fácil', duration: 20, spawnRate: 700, minFallSpeed: 4, maxFallSpeed: 6, color: 'bg-green-500', borderColor: 'border-green-700' },
  medium: { name: 'Medio', duration: 15, spawnRate: 500, minFallSpeed: 3, maxFallSpeed: 4, color: 'bg-yellow-500', borderColor: 'border-yellow-700' },
  hard: { name: 'Difícil', duration: 10, spawnRate: 350, minFallSpeed: 2, maxFallSpeed: 3, color: 'bg-red-500', borderColor: 'border-red-700' },
};

// --- High Score Feature ---
type HighScores = {
  easy: number;
  medium: number;
  hard: number;
};
const HIGH_SCORES_KEY = 'monedaventura_coinDropHighScores';
// -------------------------


interface CoinDropGameScreenProps {
  onFinish: (score: number) => void;
  onQuit: () => void;
}

const CoinDropGameScreen: React.FC<CoinDropGameScreenProps> = ({ onFinish, onQuit }) => {
  const [gameState, setGameState] = useState<'selectingDifficulty' | 'ready' | 'playing' | 'finished'>('selectingDifficulty');
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null);
  const [selectedDifficultyKey, setSelectedDifficultyKey] = useState<keyof HighScores | null>(null);
  const [coins, setCoins] = useState<Coin[]>([]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [showTutorial, setShowTutorial] = useState(false);
  const [isQuitConfirmVisible, setIsQuitConfirmVisible] = useState(false);
  const [highScores, setHighScores] = useState<HighScores>({ easy: 0, medium: 0, hard: 0 });
  const [isNewHighScore, setIsNewHighScore] = useState(false);
  
  const gameIntervalRef = useRef<number | null>(null);
  const coinSpawnerRef = useRef<number | null>(null);

  // Load high scores on mount
  useEffect(() => {
    const storedScores = localStorage.getItem(HIGH_SCORES_KEY);
    if (storedScores) {
        try {
            const parsedScores = JSON.parse(storedScores);
            if (parsedScores.easy !== undefined && parsedScores.medium !== undefined && parsedScores.hard !== undefined) {
                setHighScores(parsedScores);
            }
        } catch (e) {
            console.error("Failed to parse high scores from localStorage", e);
        }
    }
  }, []);

  useEffect(() => {
    const hasSeenTutorial = localStorage.getItem('coinDropTutorialSeen');
    if (!hasSeenTutorial) {
      setShowTutorial(true);
    }
  }, []);

  // Check and save high score when game finishes
  useEffect(() => {
    if (gameState === 'finished' && selectedDifficultyKey) {
        setHighScores(prevHighScores => {
            if (score > prevHighScores[selectedDifficultyKey]) {
                setIsNewHighScore(true);
                const newHighScores = { ...prevHighScores, [selectedDifficultyKey]: score };
                localStorage.setItem(HIGH_SCORES_KEY, JSON.stringify(newHighScores));
                return newHighScores;
            }
            return prevHighScores;
        });
    }
  }, [gameState, score, selectedDifficultyKey]);

  const handleFinishTutorial = () => {
    setShowTutorial(false);
    localStorage.setItem('coinDropTutorialSeen', 'true');
  };

  const startGame = () => {
    if (!difficulty) return;
    setScore(0);
    setTimeLeft(difficulty.duration);
    setCoins([]);
    setGameState('playing');
    setIsNewHighScore(false);
  };

  const handleCatchCoin = (id: number) => {
    setCoins(prevCoins =>
      prevCoins.map(coin => (coin.id === id ? { ...coin, caught: true } : coin))
    );
    setScore(prevScore => prevScore + 1);
  };
  
  const spawnCoin = useCallback(() => {
    if (!difficulty) return;
    const fallDurationRange = difficulty.maxFallSpeed - difficulty.minFallSpeed;
    const newCoin: Coin = {
      id: Date.now() + Math.random(),
      left: Math.random() * 90, // %
      duration: Math.random() * fallDurationRange + difficulty.minFallSpeed,
      delay: Math.random() * 0.5,
      caught: false,
    };
    setCoins(prev => [...prev, newCoin]);
  }, [difficulty]);
  
  useEffect(() => {
    // Pause game if quit confirmation is visible
    if (isQuitConfirmVisible) {
        if (gameIntervalRef.current) clearInterval(gameIntervalRef.current);
        if (coinSpawnerRef.current) clearInterval(coinSpawnerRef.current);
        return;
    }
      
    if (gameState !== 'playing' || !difficulty) return;

    gameIntervalRef.current = window.setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          if (gameIntervalRef.current) clearInterval(gameIntervalRef.current);
          if (coinSpawnerRef.current) clearInterval(coinSpawnerRef.current);
          setGameState('finished');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    coinSpawnerRef.current = window.setInterval(spawnCoin, difficulty.spawnRate);

    return () => {
      if (gameIntervalRef.current) clearInterval(gameIntervalRef.current);
      if (coinSpawnerRef.current) clearInterval(coinSpawnerRef.current);
    };
  }, [gameState, spawnCoin, difficulty, isQuitConfirmVisible]);
  
  const handleRequestQuit = () => {
    setIsQuitConfirmVisible(true);
  };

  const handleConfirmQuit = () => {
    setIsQuitConfirmVisible(false);
    onQuit();
  };
  
  const handleCancelQuit = () => {
    setIsQuitConfirmVisible(false);
  };

  const renderQuitConfirmationDialog = () => {
    if (!isQuitConfirmVisible) return null;
    return (
        <div className="absolute inset-0 bg-black/70 flex items-center justify-center p-6 z-50 animate-fade-in">
            <div className="bg-white rounded-2xl p-6 text-center shadow-2xl max-w-sm">
                <h2 className="text-xl font-black text-gray-800 mb-2">¿Seguro que quieres salir?</h2>
                <p className="text-gray-600 font-semibold mb-6">Tu progreso se perderá.</p>
                <div className="flex gap-3">
                    <button onClick={handleConfirmQuit} className="flex-1 bg-red-500 text-white font-bold py-3 rounded-full shadow-lg border-b-4 border-red-700 active:scale-95 transition-transform">
                        Sí, salir
                    </button>
                    <button onClick={handleCancelQuit} className="flex-1 bg-gray-200 text-gray-800 font-bold py-3 rounded-full active:scale-95 transition-transform">
                        Cancelar
                    </button>
                </div>
            </div>
        </div>
    );
  };
  
  const renderDifficultySelector = () => (
      <div className="relative flex flex-col items-center justify-center h-full text-center p-6 bg-blue-400 text-white">
        <button onClick={onQuit} className="absolute top-6 left-6 bg-white/20 p-2 rounded-full hover:bg-white/40 transition-colors z-10" aria-label="Volver al mapa de misiones">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor" className="w-6 h-6 text-white">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
            </svg>
        </button>
        <h1 className="text-4xl font-black mb-4">¡Lluvia de Monedas! 🪙💰</h1>
        <p className="text-lg mb-8">Elige una dificultad para empezar.</p>
        <div className="w-full space-y-4">
          {Object.entries(difficulties).map(([key, d]) => (
            <button
              key={d.name}
              onClick={() => {
                setDifficulty(d);
                setSelectedDifficultyKey(key as keyof HighScores);
                setGameState('ready');
              }}
              className={`w-full ${d.color} text-white font-extrabold text-2xl py-4 rounded-full shadow-lg border-b-4 ${d.borderColor} transform transition-transform duration-150 hover:scale-105 active:scale-100 active:border-b-2`}
            >
              {d.name}
            </button>
          ))}
        </div>
      </div>
  );
  
  const renderTutorial = () => {
    if (!showTutorial || gameState !== 'selectingDifficulty') return null;

    return (
      <div className="absolute inset-0 bg-black/70 flex items-center justify-center p-6 z-50 animate-fade-in">
        <div className="bg-white rounded-2xl p-6 pt-16 text-center shadow-2xl max-w-sm relative">
          <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-yellow-300 rounded-full flex items-center justify-center text-5xl border-4 border-white">
            🪙
          </div>
          <h2 className="text-2xl font-black text-gray-800 mb-2">¡Bienvenido a Lluvia de Monedas!</h2>
          <p className="text-gray-600 font-semibold mb-4 text-left">
            <strong>1. Elige una dificultad:</strong> ¡Decide qué tan rápido caerán las monedas!
          </p>
          <p className="text-gray-600 font-semibold mb-6 text-left">
            <strong>2. Atrapa las monedas:</strong> ¡Tócalas con el dedo antes de que desaparezcan!
          </p>
          <button onClick={handleFinishTutorial} className="w-full bg-green-500 text-white font-extrabold py-3 rounded-full shadow-lg border-b-4 border-green-700 active:scale-95 transition-transform">
            ¡Entendido!
          </button>
        </div>
      </div>
    );
  };

  const renderGameState = () => {
    switch (gameState) {
      case 'selectingDifficulty':
        return renderDifficultySelector();
      case 'ready':
        if (!difficulty) return null;
        return (
          <div className="relative flex flex-col items-center justify-center h-full text-center p-6 bg-blue-400 text-white">
            <button onClick={() => setGameState('selectingDifficulty')} className="absolute top-6 left-6 bg-white/20 p-2 rounded-full hover:bg-white/40 transition-colors z-10" aria-label="Cambiar dificultad">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor" className="w-6 h-6 text-white">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
                </svg>
            </button>
            <h1 className="text-4xl font-black mb-2">¡Lluvia de Monedas! 🪙💰</h1>
            <p className="text-lg mb-6">Atrapa tantas monedas como puedas en {difficulty.duration} segundos.</p>
            <button onClick={startGame} className="w-full bg-[#FDD201] text-gray-800 font-extrabold text-2xl py-4 rounded-full shadow-lg border-b-4 border-yellow-500 transform transition-transform duration-150 hover:scale-105 active:scale-100 active:border-b-2">
              ¡Empezar! 🚀
            </button>
          </div>
        );
      case 'finished':
        const highScore = selectedDifficultyKey ? highScores[selectedDifficultyKey] : 0;
        return (
          <div className="flex flex-col items-center justify-center h-full text-center p-6 bg-green-400 text-white">
            <h1 className="text-4xl font-black mb-2">¡Tiempo! ⏰</h1>
            <p className="text-2xl mb-4">Atrapaste</p>
            <p className="text-8xl font-black my-4 animate-bounce">{score}</p>
            <p className="text-2xl mb-2">monedas 🪙</p>
             <div className="h-16 mb-2 flex flex-col justify-center items-center">
                {isNewHighScore && (
                    <div className="bg-yellow-300 text-yellow-800 font-bold px-4 py-2 rounded-full mb-2 animate-bounce">
                        ¡Nuevo Récord! 🏆
                    </div>
                )}
                <p className="font-bold text-white/80">Récord de Dificultad: {highScore}</p>
            </div>
            <button onClick={() => onFinish(score)} className="w-full bg-[#FDD201] text-gray-800 font-extrabold text-2xl py-4 rounded-full shadow-lg border-b-4 border-yellow-500 transform transition-transform duration-150 hover:scale-105 active:scale-100 active:border-b-2">
              ¡Genial! 🤩
            </button>
             <button onClick={() => setGameState('selectingDifficulty')} className="w-full bg-white/30 text-white font-extrabold text-lg py-3 mt-4 rounded-full shadow-md transform transition-transform duration-150 hover:scale-105 active:scale-100">
                Jugar de nuevo
            </button>
          </div>
        );
      case 'playing':
        if (!difficulty) return null;
        return (
          <div className="relative h-full w-full overflow-hidden bg-gradient-to-b from-blue-300 to-sky-500">
            {/* Game UI */}
            <div className="absolute top-0 left-0 right-0 p-3 flex items-center justify-between z-10 gap-2">
                <button onClick={handleRequestQuit} className="flex-shrink-0 bg-red-500/80 text-white w-10 h-10 rounded-full font-bold text-lg flex items-center justify-center shadow-md active:scale-90 transition-transform">X</button>
                <div className="flex-grow bg-black/30 rounded-full h-8 p-1 flex items-center relative">
                    <div 
                        className={`h-full rounded-full transition-all duration-1000 ease-linear ${difficulty.color}`}
                        style={{ width: `${(timeLeft / difficulty.duration) * 100}%` }}
                    ></div>
                    <span className="absolute inset-0 flex items-center justify-center text-white font-bold text-sm" style={{textShadow: '1px 1px 2px rgba(0,0,0,0.7)'}}>
                        Tiempo: {timeLeft}s
                    </span>
                </div>
                <div className="flex-shrink-0 bg-black/30 text-white px-3 py-2 rounded-lg font-bold">🪙 {score}</div>
            </div>

            {/* Falling Coins */}
            {coins.map(coin => (
              <img
                key={coin.id}
                src={COIN_GAME_URL}
                alt="coin"
                className={`absolute w-12 h-12 cursor-pointer ${coin.caught ? 'animate-caught' : 'animate-fall'}`}
                style={{ 
                  left: `${coin.left}%`,
                   '--fall-duration': `${coin.duration}s`,
                   '--fall-delay': `${coin.delay}s`,
                   animationPlayState: isQuitConfirmVisible ? 'paused' : 'running'
                } as React.CSSProperties}
                onClick={() => !coin.caught && handleCatchCoin(coin.id)}
              />
            ))}
          </div>
        );
    }
  };

  return (
    <>
      {renderGameState()}
      {renderTutorial()}
      {renderQuitConfirmationDialog()}
      <style>{`
        @keyframes fall {
          from { transform: translateY(-100px); }
          to { transform: translateY(calc(812px - 100px)); }
        }
        .animate-fall {
          animation: fall var(--fall-duration) linear var(--fall-delay) forwards;
        }
        @keyframes caught {
          0% { transform: scale(1) rotate(0deg); opacity: 1; filter: brightness(1); }
          50% { filter: brightness(2.5) drop-shadow(0 0 10px #fff); }
          100% { transform: scale(2) rotate(360deg); opacity: 0; filter: brightness(1); }
        }
        .animate-caught {
          animation: caught 0.4s ease-out forwards;
        }
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fade-in {
          animation: fade-in 0.3s ease-out forwards;
        }
      `}</style>
    </>
  );
};

export default CoinDropGameScreen;