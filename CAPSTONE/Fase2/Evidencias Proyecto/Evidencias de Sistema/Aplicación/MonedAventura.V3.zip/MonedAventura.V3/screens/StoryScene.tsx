import React, { useState, useEffect } from 'react';
import { NEEDS_WANTS_MISSION_URL, MAIN_FOX_URL } from '../types';

interface StorySceneProps {
    onFinish: (coinsEarned: number) => void;
}

const StoryScene: React.FC<StorySceneProps> = ({ onFinish }) => {
    const [step, setStep] = useState(0);
    const [feedback, setFeedback] = useState<string | null>(null);
    const [storyContent, setStoryContent] = useState({
        title: 'La Aventura de la Sed y el Juguete',
        pages: [
            '¡Hola! Soy Fíli, el zorro explorador. Hoy te necesito para una misión muy importante. ¿Estás listo?',
            'Imagina que hemos caminado mucho bajo el sol. ¡Tenemos muchísima sed! De repente, vemos una tienda.',
            'En la tienda hay dos cosas: una botella de agua fresca y un juguete muy brillante y divertido.',
            'Tenemos solo una moneda. ¿Qué deberíamos comprar para calmar nuestra sed? ¿El agua o el juguete?'
        ],
        choices: [
            { text: 'Comprar Agua 💧', isCorrect: true },
            { text: 'Comprar Juguete 🚀', isCorrect: false },
        ]
    });

    const handleChoice = (isCorrect: boolean) => {
        if (isCorrect) {
            setFeedback('¡Correcto! El agua es una necesidad, algo que necesitamos para estar sanos. ¡Hemos aprendido algo muy valioso! Ganaste 20 monedas.');
            setTimeout(() => onFinish(20), 3000);
        } else {
            setFeedback('Casi... El juguete es un deseo, algo que queremos pero no necesitamos para vivir. ¡El agua es más importante ahora mismo! Inténtalo de nuevo.');
            setTimeout(() => setFeedback(null), 3000);
        }
    };

    const handleNext = () => {
        if (step < storyContent.pages.length - 1) {
            setStep(s => s + 1);
        }
    }

    const currentPageText = storyContent.pages[step];
    const isQuestionStep = step === storyContent.pages.length - 1;

    // A simple fade-in animation for text
    const [textOpacity, setTextOpacity] = useState(0);
    useEffect(() => {
        setTextOpacity(0);
        const timer = setTimeout(() => setTextOpacity(1), 100);
        return () => clearTimeout(timer);
    }, [step]);


    return (
        <div className="h-full flex flex-col bg-gradient-to-b from-sky-200 to-sky-400 p-4 text-center">
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 flex-grow flex flex-col justify-between shadow-lg">
                <div>
                    <img src={NEEDS_WANTS_MISSION_URL} alt="Misión" className="w-full h-32 object-cover rounded-xl mb-4"/>
                    <h1 className="text-2xl font-black text-gray-800 mb-4">{storyContent.title}</h1>
                    <p className="text-gray-700 font-semibold text-lg min-h-[100px] transition-opacity duration-500" style={{ opacity: textOpacity }}>
                        {currentPageText}
                    </p>
                </div>
                
                {feedback ? (
                    <div className={`p-3 rounded-lg font-bold ${feedback.includes('Correcto') ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>
                        {feedback}
                    </div>
                ) : (
                    <div className="mt-4">
                        {isQuestionStep ? (
                            <div className="space-y-3">
                                {storyContent.choices.map((choice, index) => (
                                    <button 
                                        key={index}
                                        onClick={() => handleChoice(choice.isCorrect)}
                                        className="w-full bg-[#FDD201] text-gray-800 font-extrabold text-lg py-3 rounded-full shadow-lg border-b-4 border-[#E9B800] transform transition-transform duration-150 hover:scale-105 active:scale-100 active:border-b-2"
                                    >
                                        {choice.text}
                                    </button>
                                ))}
                            </div>
                        ) : (
                            <button onClick={handleNext} className="w-full bg-[#96D850] text-white font-extrabold text-lg py-3 rounded-full shadow-lg border-b-4 border-green-600 transition-transform duration-150 active:scale-95 active:border-b-2">
                                Continuar →
                            </button>
                        )}
                    </div>
                )}
            </div>
            <img src={MAIN_FOX_URL} alt="Fíli el Zorro" className="h-28 mx-auto mt-2"/>
        </div>
    );
};

export default StoryScene;
