import React, { useState, useMemo, useEffect } from 'react';
import { User, Landscape, landscapes, missionsData, CHEST_LOCKED_ICON_URL, CHEST_GOLD_ICON_URL, CHEST_MAIN_ICON_URL, COIN_FLOAT_URL, SFX_BIRTHDAY_COMPLETE, SFX_HALLOWEEN_COMPLETE, SFX_CHRISTMAS_COMPLETE, SFX_BIRTHDAY_CHEST, SFX_HALLOWEEN_CHEST, SFX_CHRISTMAS_CHEST, AVATARS, ScreenName } from '../types';
import ProgressModal from '../components/ProgressModal';

type MissionStatus = 'completed' | 'active' | 'locked';

// Sound Effects
const sounds: Record<Landscape, { complete: HTMLAudioElement; chest: HTMLAudioElement }> = {
    birthday: {
        complete: new Audio(SFX_BIRTHDAY_COMPLETE),
        chest: new Audio(SFX_BIRTHDAY_CHEST)
    },
    halloween: {
        complete: new Audio(SFX_HALLOWEEN_COMPLETE),
        chest: new Audio(SFX_HALLOWEEN_CHEST)
    },
    christmas: {
        complete: new Audio(SFX_CHRISTMAS_COMPLETE),
        chest: new Audio(SFX_CHRISTMAS_CHEST)
    }
};

const playSound = (sound: HTMLAudioElement) => {
    sound.currentTime = 0;
    sound.play().catch(error => console.error("Error playing sound:", error));
};

const motivationalMessages = [ "¡Elegiste sabiamente!", "¡Tu ahorro iluminó el camino!", "¡Cada paso es un logro!", "¡Sigue así, campeón/a!", "¡Tu esfuerzo vale oro!", "Elegiste sabiamente, joven aventurero de las monedas"];

const Particle: React.FC<{ style: React.CSSProperties; landscape: Landscape }> = ({ style, landscape }) => {
    let content;
    let particleStyle: React.CSSProperties = {};
    switch (landscape) {
        case 'halloween':
            content = '🍁';
            particleStyle = { fontSize: '14px', filter: `hue-rotate(${Math.random() * 50}deg) saturate(2)`, opacity: 0.7 };
            break;
        case 'christmas':
            content = '❄️';
            particleStyle = { fontSize: '12px', filter: `saturate(1.5)` };
            break;
        case 'birthday':
        default:
             return <div className="absolute w-2 h-4" style={style} />;
    }
    return <div className="absolute" style={{...style, ...particleStyle, backgroundColor: 'transparent'}}>{content}</div>
};


const FloatingCoin: React.FC<{ style: React.CSSProperties }> = ({ style }) => (
    <img src={COIN_FLOAT_URL} className="absolute w-8 h-8 pointer-events-none" style={style} alt="coin" />
);

const EffectsLayer: React.FC<{ missionId: string; pos: { top: string; left: string }; landscape: Landscape }> = ({ missionId, pos, landscape }) => {
    const particles = Array.from({ length: 30 }).map((_, i) => ({
        transform: `translate(-50%, -50%) rotate(${Math.random() * 360}deg) translateX(${Math.random() * 80}px) scale(0)`,
        backgroundColor: landscape === 'birthday' ? ['#fde18a', '#ff74b1', '#a8e6cf', '#f4a261'][i % 4] : 'transparent',
        animation: `particle-burst 0.8s ${i * 0.015}s ease-out forwards`,
    }));
    
    const coins = Array.from({ length: 5 }).map((_, i) => ({
        transform: `translate(-50%, -50%) translateX(${(Math.random() - 0.5) * 40}px) scale(0)`,
        animation: `coin-float 1s ${i * 0.1 + 0.2}s ease-out forwards`,
    }));

    return (
        <div className="absolute pointer-events-none z-50" style={pos}>
            {particles.map((style, i) => <Particle key={`p-${i}`} style={style} landscape={landscape} />)}
            {coins.map((style, i) => <FloatingCoin key={`m-${i}`} style={style} />)}
        </div>
    );
};

const LandscapeEffects: React.FC<{ landscape: Landscape }> = ({ landscape }) => {
    const particles = useMemo(() => Array.from({ length: 15 }).map((_, i) => ({
        id: i,
        style: {
            left: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 10}s`,
            animationDuration: `${Math.random() * 10 + 8}s`,
        }
    })), [landscape]);

    let particleContent, animationName;

    switch (landscape) {
        case 'birthday':
            particleContent = ['🎉', '✨', '🎊', '🎈'];
            animationName = 'animate-confetti-fall';
            break;
        case 'halloween':
            particleContent = ['👻', '🎃', '🦇'];
            animationName = 'animate-ghost-float';
            break;
        case 'christmas':
            particleContent = ['❄️', '✨'];
            animationName = 'animate-snow-fall';
            break;
        default:
            return null;
    }

    return (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
            {particles.map(p => (
                <div key={p.id} className={`absolute text-2xl opacity-70 ${animationName}`} style={p.style}>
                    {particleContent[p.id % particleContent.length]}
                </div>
            ))}
        </div>
    );
};


const MissionModal: React.FC<{ mission: any; status: MissionStatus; onClose: () => void; onStart: () => void; landscape: Landscape; }> = ({ mission, status, onClose, onStart, landscape }) => {
    
    useEffect(() => {
        if(status === 'completed') {
            playSound(sounds[landscape].chest);
        }
    }, [status, landscape]);
    
    return (
        <div className="absolute inset-0 bg-black/60 flex items-center justify-center p-4 z-40" onClick={onClose}>
            <div className="bg-white rounded-2xl p-6 w-full max-w-sm text-center animate-modal-in border-t-8" style={{ borderColor: landscapes[landscape].mainColor }} onClick={(e) => e.stopPropagation()}>
                <img src={mission.icon} alt={mission.name} className="w-24 h-24 mx-auto mb-3 drop-shadow-lg" />
                <h2 className="text-2xl font-black text-gray-800 mb-2">{mission.name}</h2>
                <p className="text-gray-600 font-semibold mb-4 text-sm">{mission.description}</p>
                <p className="text-gray-500 mb-4">Estado: <span className={`font-bold ${status === 'completed' ? 'text-green-500' : status === 'active' ? 'text-blue-500' : 'text-gray-500'}`}>{status === 'completed' ? '¡Completado! 🎉' : status === 'active' ? '¡Listo para la aventura!' : 'Bloqueado'}</span></p>
                {status === 'active' && (
                    <button onClick={onStart} className="w-full bg-[#FDD201] text-gray-800 font-extrabold text-lg py-3 rounded-full shadow-lg border-b-4 border-yellow-500 active:scale-95 transition-transform">
                        Comenzar misión
                    </button>
                )}
                <button onClick={onClose} className="w-full text-gray-500 font-bold py-2 mt-2">
                    Cerrar
                </button>
            </div>
        </div>
    );
};

const MissionNode: React.FC<{ mission: any; status: MissionStatus; onClick: () => void; }> = ({ mission, status, onClick }) => {
    const isSpecialChest = mission.id.endsWith('10');
    let chestIcon;
    if (status === 'locked') chestIcon = CHEST_LOCKED_ICON_URL;
    else if (status === 'completed') chestIcon = isSpecialChest ? CHEST_MAIN_ICON_URL : CHEST_GOLD_ICON_URL;
    else chestIcon = isSpecialChest ? CHEST_MAIN_ICON_URL : CHEST_LOCKED_ICON_URL;

    return (
        <button disabled={status === 'locked'} className={`absolute transform -translate-x-1/2 -translate-y-1/2 group ${status !== 'locked' ? 'cursor-pointer' : 'cursor-default'}`} style={mission.pos} onClick={status !== 'locked' ? onClick : undefined}>
            <div className={`relative flex flex-col items-center transition-transform duration-300 ${status === 'active' ? 'animate-active-mission' : status !== 'locked' ? 'hover:scale-110' : ''}`}>
                <img src={mission.icon} alt="" className={`w-12 h-12 mb-1 drop-shadow-lg ${status === 'locked' ? 'grayscale opacity-60' : ''}`} />
                <div className={`relative ${isSpecialChest ? 'w-20 h-20' : 'w-14 h-14'}`}>
                    <img src={chestIcon} alt="Cofre" className="w-full h-full drop-shadow-lg" />
                    {status === 'completed' && <div className="absolute inset-0 animate-chest-glow rounded-full"></div>}
                </div>
                 <p className={`absolute -bottom-5 w-24 text-center font-extrabold text-white text-xs px-2 py-0.5 rounded-full ${status === 'locked' ? 'bg-gray-500/80' : 'bg-black/50'}`} style={{textShadow: '1px 1px 2px rgba(0,0,0,0.8)'}}>{mission.name}</p>
                 <div className="absolute top-full mt-2 w-48 bg-black/70 text-white text-xs rounded-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-50">
                    {mission.description}
                </div>
            </div>
        </button>
    );
};

interface MissionsScreenProps {
    user: User;
    onPlayMission: (missionId: string) => void;
    onNavigate: (screen: ScreenName) => void;
}

const MissionsScreen: React.FC<MissionsScreenProps> = ({ user, onPlayMission, onNavigate }) => {
    const [currentLandscape, setCurrentLandscape] = useState<Landscape>('birthday');
    const [selectedMission, setSelectedMission] = useState<{mission: any, status: MissionStatus} | null>(null);
    const [effects, setEffects] = useState<{ id: string; pos: { top: string; left: string } } | null>(null);
    const [activeMessage, setActiveMessage] = useState('');
    const [isProgressModalOpen, setIsProgressModalOpen] = useState(false);
    const completedMissions = user.completedMissions ?? [];
    const prevCompletedMissions = React.useRef(completedMissions);

    const avatarUrl = user.customAvatarUrl || AVATARS[user.avatarId ?? 'boy'].image;

    useEffect(() => {
        const message = motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];
        setActiveMessage(message);
        const timer = setTimeout(() => setActiveMessage(''), 3000); // 3s duration
        return () => clearTimeout(timer);
    }, [currentLandscape]);

    const { statuses: missionStatuses, activeMission } = useMemo(() => {
        const statuses: { [key: string]: MissionStatus } = {};
        const landscapeMissions = missionsData[currentLandscape];
        let firstLockedFound = false;
        let activeMission = null;

        for (const mission of landscapeMissions) {
            if (completedMissions.includes(mission.id)) {
                statuses[mission.id] = 'completed';
            } else if (!firstLockedFound) {
                statuses[mission.id] = 'active';
                activeMission = mission;
                firstLockedFound = true;
            } else {
                statuses[mission.id] = 'locked';
            }
        }
        return { statuses, activeMission };
    }, [user, currentLandscape, completedMissions]);
    
    useEffect(() => {
      const newCompletions = completedMissions.filter(id => !prevCompletedMissions.current.includes(id));
      if (newCompletions.length > 0) {
        const lastCompletedId = newCompletions[newCompletions.length - 1];
        const missionData = missionsData[currentLandscape].find(m => m.id === lastCompletedId);
        if (missionData) {
          playSound(sounds[currentLandscape].complete);
          setEffects({ id: lastCompletedId, pos: missionData.pos });
          setTimeout(() => setEffects(null), 2000);
        }
      }
      prevCompletedMissions.current = completedMissions;
    }, [completedMissions, currentLandscape]);

    const handleStartActiveMission = () => {
        if (activeMission) {
            if (activeMission.id.endsWith('10')) {
                onPlayMission(activeMission.id);
            } else {
                 setSelectedMission({ mission: activeMission, status: 'active' });
            }
        }
    };
    
    const generateCurvePath = (startPos: any, endPos: any) => {
        const from = { x: parseFloat(startPos.left), y: parseFloat(startPos.top) };
        const to = { x: parseFloat(endPos.left), y: parseFloat(endPos.top) };
        const dx = to.x - from.x;
        const dy = to.y - from.y;
        const midX = from.x + dx * 0.5;
        const midY = from.y + dy * 0.5;
        const curveIntensity = 15;
        const controlX = midX + dy * (curveIntensity / 100);
        const controlY = midY - dx * (curveIntensity / 100);
        return `M${from.x},${from.y} Q${controlX},${controlY} ${to.x},${to.y}`;
    };

    return (
        <>
            <style>{`
                @keyframes active-mission { 0%, 100% { transform: scale(1.1) rotate(-2deg); filter: drop-shadow(0 0 10px #fff); } 50% { transform: scale(1.2) rotate(2deg); filter: drop-shadow(0 0 15px #fff); } }
                .animate-active-mission { animation: active-mission 2s ease-in-out infinite; }
                @keyframes chest-glow { 0%, 100% { box-shadow: 0 0 20px 5px rgba(253, 224, 71, 0.7); opacity: 0.7; } 50% { box-shadow: 0 0 30px 10px rgba(253, 224, 71, 1); opacity: 1; } }
                @keyframes modal-in { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }
                .animate-modal-in { animation: modal-in 0.3s ease-out; }
                @keyframes particle-burst { 0% { transform: translate(-50%, -50%) rotate(0) scale(0); opacity: 1; } 100% { transform: translate(-50%, -50%) rotate(360deg) scale(1.5); opacity: 0; } }
                @keyframes coin-float { 0% { opacity: 0; transform: translate(-50%, -50%) scale(0) translateY(0); } 50% { opacity: 1; transform: translate(-50%, -50%) scale(1.2) } 100% { opacity: 0; transform: translate(-50%, -50%) scale(1) translateY(-100px); } }
                @keyframes message-fade { 0% { opacity: 0; transform: translateY(10px); } 10% { opacity: 1; transform: translateY(0); } 90% { opacity: 1; transform: translateY(0); } 100% { opacity: 0; transform: translateY(-10px); } }
                .animate-message-fade { animation: message-fade 3s ease-in-out forwards; }
                @keyframes path-glow { from { stroke-dashoffset: 20; } to { stroke-dashoffset: 0; } }
                .animate-path-glow { animation: path-glow 1.5s linear infinite; }
                @keyframes avatar-bounce { 0%, 100% { transform: translateY(0) scale(1); } 50% { transform: translateY(-4px) scale(1.05); } }
                .animate-avatar-bounce { animation: avatar-bounce 2.5s ease-in-out infinite; }

                @keyframes snow-fall {
                    0% { transform: translateY(-10vh) translateX(0) rotate(0deg); opacity: 0; }
                    10% { opacity: 1; }
                    100% { transform: translateY(100vh) translateX(5vw) rotate(360deg); opacity: 1; }
                }
                .animate-snow-fall { animation: snow-fall linear infinite; }

                @keyframes ghost-float {
                    0% { transform: translateY(100vh) translateX(0) scale(1); opacity: 0; }
                    10% { opacity: 0.7; }
                    50% { transform: translateY(50vh) translateX(10vw) scale(1.2); }
                    90% { opacity: 0.7; }
                    100% { transform: translateY(-10vh) translateX(-10vw) scale(1); opacity: 0; }
                }
                .animate-ghost-float { animation: ghost-float ease-in-out infinite; }

                @keyframes confetti-fall {
                    0% { transform: translateY(-10vh) rotateZ(0deg); opacity: 1; }
                    100% { transform: translateY(100vh) rotateZ(720deg); opacity: 0; }
                }
                .animate-confetti-fall { animation: confetti-fall linear infinite; }

            `}</style>
            <div className="w-full h-full bg-cover bg-center flex flex-col overflow-hidden" style={{ backgroundImage: `url(${landscapes[currentLandscape].bg})` }}>
                <LandscapeEffects landscape={currentLandscape} />
                {selectedMission && <MissionModal mission={selectedMission.mission} status={selectedMission.status} onClose={() => setSelectedMission(null)} onStart={() => onPlayMission(selectedMission.mission.id)} landscape={currentLandscape} />}
                {isProgressModalOpen && <ProgressModal user={user} userRole="child" onClose={() => setIsProgressModalOpen(false)} />}
                
                <header className="p-4 relative z-20 flex justify-between items-center">
                    <div className="w-12 h-12">
                         <button onClick={() => onNavigate('profile')} title="Cambiar avatar">
                            <img 
                                src={avatarUrl} 
                                alt="Tu Avatar" 
                                className="w-12 h-12 rounded-full border-2 border-white shadow-lg animate-avatar-bounce object-cover"
                            />
                        </button>
                    </div>
                    <div className="flex-grow flex justify-center">
                        <div className="flex justify-center bg-black/30 backdrop-blur-sm rounded-full p-1 max-w-xs w-full">
                            {Object.keys(landscapes).map((key) => (
                                <button
                                    key={key}
                                    onClick={() => setCurrentLandscape(key as Landscape)}
                                    className={`flex-1 text-white font-bold py-2 px-3 rounded-full text-xs transition-colors duration-300 ${currentLandscape === key ? 'bg-white/30' : ''}`}
                                >
                                    {landscapes[key as Landscape].name}
                                </button>
                            ))}
                        </div>
                    </div>
                     <div className="w-12 h-12"></div>
                </header>

                <div className="flex-grow relative">
                    {activeMessage && <p className="absolute top-0 left-1/2 -translate-x-1/2 font-extrabold text-white text-lg animate-message-fade" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.5)' }}>{activeMessage}</p>}
                    <svg className="absolute top-0 left-0 w-full h-full pointer-events-none" preserveAspectRatio="none" viewBox="0 0 100 100">
                        {missionsData[currentLandscape].slice(0, -1).map((mission, index) => {
                             const nextMission = missionsData[currentLandscape][index + 1];
                             const isPathUnlocked = missionStatuses[mission.id] === 'completed';
                             const pathData = generateCurvePath(mission.pos, nextMission.pos);
                             return (
                                <g key={index}>
                                 <path
                                     d={pathData}
                                     stroke={isPathUnlocked ? landscapes[currentLandscape].pathColor : 'rgba(255,255,255,0.3)'}
                                     strokeWidth="1"
                                     fill="none"
                                     strokeDasharray="2 1.5"
                                     strokeLinecap="round"
                                     style={{ filter: 'drop-shadow(1px 1px 2px rgba(0,0,0,0.5))' }}
                                 />
                                 {isPathUnlocked && missionStatuses[nextMission.id] === 'active' &&
                                    <path
                                      d={pathData}
                                      stroke="white"
                                      strokeWidth="1.2"
                                      fill="none"
                                      strokeDasharray="2 1.5"
                                      strokeLinecap="round"
                                      className="animate-path-glow"
                                    />
                                  }
                                 </g>
                             );
                        })}
                    </svg>

                    {missionsData[currentLandscape].map(mission => (
                        <MissionNode 
                          key={mission.id} 
                          mission={mission} 
                          status={missionStatuses[mission.id]} 
                          onClick={() => setSelectedMission({mission, status: missionStatuses[mission.id]})} 
                        />
                    ))}
                    {effects && <EffectsLayer missionId={effects.id} pos={effects.pos} landscape={currentLandscape}/>}
                </div>
                 <footer className="p-4 z-30 flex justify-center items-center gap-4">
                    <button 
                        onClick={() => setIsProgressModalOpen(true)}
                        className="bg-white/80 backdrop-blur-sm text-gray-800 font-bold py-2 px-5 rounded-full shadow-lg transition-transform active:scale-95">
                        Ver progreso
                    </button>
                    <button 
                        onClick={handleStartActiveMission}
                        disabled={!activeMission}
                        className="text-white font-extrabold py-3 px-8 rounded-full shadow-xl border-b-4 transition-transform active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed"
                        style={{
                            backgroundColor: landscapes[currentLandscape].mainColor,
                            borderColor: 'rgba(0, 0, 0, 0.25)' // A generic darker shade for the 3D effect
                        }}
                    >
                        Comenzar misión
                    </button>
                </footer>
            </div>
        </>
    );
};

export default MissionsScreen;