import React, { useState, useEffect } from 'react';
import { User, AVATARS, MAIN_FOX_URL, BICYCLE_GOAL_URL, HOME_BACKGROUND_URL, TREASURE_CHEST_URL, STAR_FLOAT_URL, COIN_FLOAT_URL, BALLOON_FLOAT_URL } from '../types';
import { CoinIcon, StarIcon, TrophyIcon, UserIcon } from '../components/Icons';

interface HomeScreenProps {
  user: User;
  onStart: () => void;
  onGoToParentsPanel: () => void;
  onGoToProfile: () => void;
}

const MissionCard: React.FC<{ title: string; icon: React.ReactNode; value: number; progress: number }> = ({ title, icon, value, progress }) => {
    const [isLoaded, setIsLoaded] = useState(false);
    useEffect(() => {
        const timer = setTimeout(() => setIsLoaded(true), 100);
        return () => clearTimeout(timer);
    }, []);

    return (
        <div className="bg-white p-3 rounded-2xl shadow-sm flex-1">
            <div className="flex items-start gap-2">
                <div className="bg-yellow-100 text-yellow-500 p-2 rounded-full">{icon}</div>
                <div>
                    <p className="text-sm font-bold text-gray-600">{title}</p>
                    <div className="flex items-center gap-1 mt-1">
                        {icon}
                        <span className="text-xs font-extrabold text-gray-700">{value}</span>
                    </div>
                </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div className="bg-gradient-to-r from-yellow-300 to-yellow-500 h-2 rounded-full transition-all duration-1000 ease-out" style={{ width: isLoaded ? `${progress}%` : '0%' }}></div>
            </div>
        </div>
    );
};

const MagicDust: React.FC = () => {
    const particles = Array.from({ length: 20 });
    return (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {particles.map((_, i) => (
                <div
                    key={i}
                    className="absolute rounded-full bg-yellow-200 animate-magic-dust"
                    style={{
                        top: `${Math.random() * 100}%`,
                        left: `${Math.random() * 100}%`,
                        width: `${Math.random() * 3 + 1}px`,
                        height: `${Math.random() * 3 + 1}px`,
                        animationDelay: `${Math.random() * 10}s`,
                        animationDuration: `${Math.random() * 10 + 5}s`,
                    }}
                />
            ))}
        </div>
    );
};

const HomeScreen: React.FC<HomeScreenProps> = ({ user, onStart, onGoToParentsPanel, onGoToProfile }) => {
  const topGoal = user.goals?.find(g => !g.isJoint) || user.goals?.[0];
  const [isLoaded, setIsLoaded] = useState(false);
  const latestMessage = user.motivationalMessages?.[user.motivationalMessages.length - 1];
  
  const avatarUrl = user.customAvatarUrl || AVATARS[user.avatarId ?? 'boy'].image;

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);


  return (
    <>
      <style>{`
          @keyframes subtleBounce {
              0%, 100% { transform: translateY(0) scale(1); }
              50% { transform: translateY(-4px) scale(1.02); }
          }
          .animate-greeting-avatar {
              animation: subtleBounce 2.5s ease-in-out infinite;
          }
          @keyframes coin-jump {
              0%, 100% { transform: scale(1); }
              50% { transform: scale(1.2) rotate(-10deg); }
          }
          .animate-coin-jump {
              animation: coin-jump 1.8s ease-in-out infinite;
          }
          @keyframes wave {
              0% { transform: rotate(0.0deg) }
              10% { transform: rotate(14.0deg) }
              20% { transform: rotate(-8.0deg) }
              30% { transform: rotate(14.0deg) }
              40% { transform: rotate(-4.0deg) }
              50% { transform: rotate(10.0deg) }
              60% { transform: rotate(0.0deg) }
              100% { transform: rotate(0.0deg) }
          }
          .animate-wave {
              animation: wave 2.5s ease-in-out infinite;
              transform-origin: 70% 70%;
              display: inline-block;
          }
          @keyframes float {
            0% { transform: translatey(0px); }
            50% { transform: translatey(-10px) rotate(3deg); }
            100% { transform: translatey(0px); }
          }
          .animate-float-1 { animation: float 4s ease-in-out infinite; }
          .animate-float-2 { animation: float 3s ease-in-out infinite; animation-delay: 1s; }
          .animate-float-3 { animation: float 5s ease-in-out infinite; }
          .animate-float-4 { animation: float 6s ease-in-out infinite; animation-delay: 2s; }
          .animate-float-5 { animation: float 4.5s ease-in-out infinite; animation-delay: 3s; }
          @keyframes magic-dust {
            0% { transform: translateY(0) scale(1); opacity: 0; }
            20% { opacity: 1; }
            80% { opacity: 1; }
            100% { transform: translateY(-100px) scale(0.5); opacity: 0; }
          }
          .animate-magic-dust {
            animation: magic-dust linear infinite;
          }
      `}</style>
      <div 
        className="w-full min-h-full bg-cover bg-center relative"
        style={{ backgroundImage: `url(${HOME_BACKGROUND_URL})` }}
      >
        <MagicDust />
        {/* Floating Elements */}
        <img src={TREASURE_CHEST_URL} className="absolute w-28 top-1/2 left-1 animate-float-1 pointer-events-none opacity-90" alt="Treasure Chest" />
        <img src={STAR_FLOAT_URL} className="absolute w-12 top-1/3 right-4 animate-float-2 pointer-events-none opacity-90" alt="Star" />
        <img src={COIN_FLOAT_URL} className="absolute w-10 top-1/4 left-8 animate-float-3 pointer-events-none opacity-95" alt="Coin" />
        <img src={BALLOON_FLOAT_URL} className="absolute w-16 top-2/3 right-2 animate-float-4 pointer-events-none opacity-90" alt="Balloon" />
        <img src={COIN_FLOAT_URL} className="absolute w-8 bottom-24 right-16 animate-float-5 pointer-events-none opacity-95" alt="Coin" />


        {/* Header */}
        <header className="p-4 pt-2 text-white rounded-b-[32px] relative overflow-hidden">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <button onClick={onGoToProfile} title="Cambiar avatar">
                <img src={avatarUrl} alt="User Avatar" className="w-10 h-10 rounded-full border-2 border-white bg-white/50 animate-greeting-avatar object-cover" />
              </button>
              <h1 className="font-bold text-lg" style={{textShadow: '1px 1px 3px rgba(0,0,0,0.5)'}}>¡Bienvenido, {user.name}! <span className="animate-wave">👋</span></h1>
            </div>
            <div className="flex items-center gap-4">
              <div className="bg-black/20 backdrop-blur-sm px-3 py-1.5 rounded-full flex items-center gap-2">
                <CoinIcon className="w-6 h-6 text-yellow-300 animate-coin-jump" />
                <span className="font-extrabold">{user.coins ?? 0}</span>
              </div>
            </div>
          </div>
          <div className="text-center relative mt-2">
            <h2 className="text-4xl font-black uppercase tracking-wide" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.2)'}}>
              MonedAventura 🪙
            </h2>
            <p className="font-semibold text-white mt-1" style={{textShadow: '1px 1px 2px rgba(0,0,0,0.4)'}}>¡Cada moneda cuenta! 💪</p>
            <img src={MAIN_FOX_URL} alt="Fox mascot" className="h-40 mx-auto -mb-10 relative z-10" />
          </div>
          <button
              onClick={onStart}
              className="w-full bg-gradient-to-r from-yellow-400 to-orange-400 text-white font-extrabold text-lg py-3 rounded-full shadow-lg border-b-4 border-yellow-600 transform transition-transform duration-150 hover:from-yellow-500 hover:to-orange-500 hover:scale-105 active:scale-100 active:border-b-2 mt-4"
          >
              ¡Jugar y Ganar! ✨
          </button>
        </header>

        {/* Main Content */}
        <main className="p-4 space-y-5 pb-24 relative">
           {/* Message from Parents */}
          {latestMessage && (
            <section className="bg-gradient-to-r from-teal-100 to-cyan-100 p-3 rounded-2xl shadow-md flex items-center gap-3">
              <span className="text-2xl">💌</span>
              <div>
                <p className="font-extrabold text-sm text-teal-800">Mensaje de Papá/Mamá:</p>
                <p className="text-gray-700 font-semibold">"{latestMessage}"</p>
              </div>
            </section>
          )}
          
          {/* Misiones */}
          <section>
            <h3 className="font-extrabold text-xl text-gray-800 mb-2" style={{textShadow: '1px 1px 2px rgba(255,255,255,0.8)'}}>Tus Misiones 🗺️</h3>
            <div className="bg-white/80 backdrop-blur-sm p-3 rounded-2xl shadow-md">
              <div className="flex gap-3 mb-3">
                <MissionCard title="Ahorrar 100 monedas" icon={<StarIcon className="w-4 h-4 text-yellow-500" />} value={user.stars ?? 0} progress={75} />
                <MissionCard title="Necesidad y deseo" icon={<TrophyIcon className="w-4 h-4 text-orange-500" />} value={user.trophies ?? 0} progress={40} />
              </div>
              <div>
                  <p className="text-sm font-bold text-gray-600 mb-1">Nivel {user.level ?? 1}</p>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-gradient-to-r from-sky-400 to-blue-500 h-2.5 rounded-full transition-all duration-1000 ease-out" style={{ width: isLoaded ? '60%' : '0%' }}></div>
                  </div>
              </div>
            </div>
          </section>

          {/* Metas de Ahorro */}
          <section>
            <h3 className="font-extrabold text-xl text-gray-800 mb-2" style={{textShadow: '1px 1px 2px rgba(255,255,255,0.8)'}}>Mi Meta Principal 🎯</h3>
            <div className="bg-white/80 backdrop-blur-sm p-4 rounded-2xl shadow-md flex items-center gap-4">
              {topGoal ? (
                <>
                  <img src={BICYCLE_GOAL_URL} alt="Meta de ahorro" className="w-20 h-20 object-contain" />
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1">
                      <h4 className="font-bold text-gray-800">{topGoal.name}</h4>
                      <p className="font-extrabold text-yellow-500">{topGoal.current} / {topGoal.target}</p>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div className="bg-gradient-to-r from-lime-400 to-green-500 h-3 rounded-full transition-all duration-1000 ease-out" style={{ width: isLoaded ? `${(topGoal.current / topGoal.target) * 100}%` : '0%' }}></div>
                    </div>
                    <p className="text-xs text-right text-gray-500 mt-1">¡Sigue así! 💪</p>
                  </div>
                </>
              ) : (
                <div className="text-center py-2 w-full">
                  <p className="font-bold text-gray-600">¡Define tu primer objetivo! 🤔</p>
                  <p className="text-sm text-gray-500">Ve a la sección de Monedas para crear una meta de ahorro.</p>
                </div>
              )}
            </div>
          </section>

          {/* Perfil */}
          <section>
            <h3 className="font-extrabold text-xl text-gray-800 mb-2" style={{textShadow: '1px 1px 2px rgba(255,255,255,0.8)'}}>Tu Perfil 👤</h3>
            <div className="bg-white/80 backdrop-blur-sm p-3 rounded-2xl shadow-md flex items-center gap-4">
              <img src={avatarUrl} alt="User Avatar" className="w-16 h-16 rounded-full border-4 border-lime-200 object-cover" />
              <div className="flex-1 flex items-center justify-between">
                  <div className="flex gap-4">
                      <div className="text-center"><StarIcon className="w-6 h-6 text-yellow-400 mx-auto"/><p className="font-bold text-sm">{user.stars ?? 0}</p></div>
                      <div className="text-center"><CoinIcon className="w-6 h-6 text-yellow-500 mx-auto"/><p className="font-bold text-sm">{user.coins ?? 0}</p></div>
                      <div className="text-center"><TrophyIcon className="w-6 h-6 text-orange-400 mx-auto"/><p className="font-bold text-sm">{user.trophies ?? 0}</p></div>
                  </div>
                  <button onClick={onGoToProfile} className="bg-gradient-to-r from-purple-400 to-pink-500 text-white font-bold text-xs px-4 py-2 rounded-full shadow-sm transition-transform duration-150 active:scale-95 hover:shadow-lg">
                      Elegir Avatar 🎨
                  </button>
              </div>
            </div>
          </section>
        </main>
      </div>
    </>
  );
};

export default HomeScreen;