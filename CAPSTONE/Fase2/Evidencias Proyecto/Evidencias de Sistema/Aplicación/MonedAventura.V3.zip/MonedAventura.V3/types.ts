// types.ts

export type ScreenName = 'login' | 'home' | 'story' | 'profile' | 'missions' | 'monedas' | 'parents';

export type AvatarId = 'boy' | 'fox' | 'cat' | 'owl';

// ADD: Define user roles for the new authentication system.
export type UserRole = 'child' | 'parent';

export const AVATARS: Record<AvatarId, { name: string; image: string }> = {
  boy: { name: 'Aventurero', image: 'https://img.freepik.com/vector-premium/personaje-dibujos-animados-explorador-aventurero_1367638-8778.jpg' },
  fox: { name: 'Zorro Astuto', image: 'https://png.pngtree.com/png-clipart/20241117/original/pngtree-a-drawing-of-fox-png-image_17190030.png' },
  cat: { name: 'Gato Curioso', image: 'https://www.shutterstock.com/image-vector/little-cute-cat-cartoon-character-600nw-2487180431.jpg' },
  owl: { name: 'Búho Sabio', image: 'https://img.freepik.com/vector-premium/buho-sabio-dibujos-animados-lindo-icono-plano-libro_444196-9784.jpg' },
};

export const MAIN_FOX_URL = 'https://images.vexels.com/media/users/3/263771/isolated/preview/c84a01bc085abe77d0e905e0682efd27-color-de-dibujos-animados-retro-moneda-feliz.png';
export const MONEDAVENTURA_LOGO_URL = 'https://png.pngtree.com/png-clipart/20241117/original/pngtree-a-drawing-of-fox-png-image_17190030.png';
export const PIGGY_BANK_URL = 'https://www.shutterstock.com/image-illustration/piggy-bank-coins-banking-finance-600nw-2523000867.jpg';
export const COIN_GAME_URL = 'https://as1.ftcdn.net/v2/jpg/04/49/05/74/1000_F_449057416_1ncCXyMa2bgHGYONXrmivQp5mSTiuM2y.jpg';

// New images for missions and goals
export const BICYCLE_GOAL_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/bicycle-goal.png';
export const NEEDS_WANTS_MISSION_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/needs-wants-mission.png';
export const WEEKLY_SAVINGS_MISSION_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/weekly-savings-mission.png';
export const WELCOME_MISSION_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/welcome-mission.png';
export const AVATAR_MISSION_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/avatar-mission.png';
export const PLAN_GOAL_MISSION_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/plan-goal-mission.png';

// New images for Home Screen
export const HOME_BACKGROUND_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/fantasy-background.png';
export const TREASURE_CHEST_URL = 'https://png.pngtree.com/png-vector/20201123/ourlarge/pngtree-cute-cartoon-treasure-chest-closed-isolated-vector-png-image_2467822.jpg';
export const STAR_FLOAT_URL = 'https://png.pngtree.com/png-clipart/20250108/original/pngtree-cartoon-happy-star-illustration-png-image_20002859.png';
export const COIN_FLOAT_URL = 'https://img.freepik.com/vector-premium/moneda-limpia-brillante-brillante-plantilla-blanco-gestion-contabilidad-financiera-cartel-economico-ilustracion-vectorial-dibujos-animados-sobre-fondo-blanco_263753-3718.jpg?w=360';
export const BALLOON_FLOAT_URL = 'https://images.vexels.com/media/users/3/334062/isolated/preview/e0d21b6502c9309033d98956557f8b96-dos-globos-de-dibujos-animados-con-caras-y-lenguas.png';


// New image for Missions Screen (old)
export const ADVENTURE_MAP_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/adventure-map-background.png';

// Mission Map Assets
export const BIRTHDAY_BG_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/birthday-balloons-bg.png';
export const HALLOWEEN_BG_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/halloween-bg-magical.png';
export const CHRISTMAS_BG_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/christmas-bg-magical.png';
export const BIRTHDAY_LOGO_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/logo-birthday.png';
export const HALLOWEEN_LOGO_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/logo-halloween.png';
export const CHRISTMAS_LOGO_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/logo-christmas.png';


export const CHEST_ICON_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/chest-icon.png';
export const CHEST_GOLD_ICON_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/chest-gold-icon.png';
export const CHEST_LOCKED_ICON_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/chest-locked-icon.png';
export const CHEST_MAIN_ICON_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/chest-main-icon.png';

export const MISSION_ICON_NOTEBOOK_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-notebook.png';
export const MISSION_ICON_CART_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-cart.png';
export const MISSION_ICON_PUMPKIN_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-pumpkin.png';
export const MISSION_ICON_GIFT_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-gift.png';
export const MISSION_ICON_SAVINGS_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-savings.png';
export const MISSION_ICON_SNOWFLAKE_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-snowflake.png';
export const MISSION_ICON_HAT_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-party-hat.png';
export const MISSION_ICON_GHOST_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-ghost.png';
export const MISSION_ICON_CANDYCANE_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-candycane.png';
export const MISSION_ICON_LABYRINTH_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-labyrinth.png';
export const MISSION_ICON_TREASURE_URL = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-treasure.png';

// Professional Mission Map Icons
export const ICON_BALLOON = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-balloon.png';
export const ICON_CAKE = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-cake.png';
export const ICON_QUESTION = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-question.png';
export const ICON_PINATA = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-pinata.png';
export const ICON_BACKPACK = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-backpack.png';
export const ICON_SURPRISE = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-surprise.png';
export const ICON_GHOST_PIGGY = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-ghost-piggy.png';
export const ICON_COSTUME = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-costume.png';
export const ICON_SWEETS = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-sweets.png';
export const ICON_COINS = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-coins.png';
export const ICON_MAGIC_OBJECT = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-magic-object.png';
export const ICON_LIST = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-list.png';
export const ICON_BASKET = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-basket.png';
export const ICON_ORNAMENT = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-ornament.png';
export const ICON_TABLE = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-table.png';
export const ICON_TREE = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-tree.png';
export const ICON_DECORATION = 'https://storage.googleapis.com/genai-assets/monedaventura/icon-decoration.png';


// Professional Mission Map Sounds
export const SFX_BIRTHDAY_COMPLETE = 'https://storage.googleapis.com/genai-assets/monedaventura/sfx-birthday-complete.mp3';
export const SFX_HALLOWEEN_COMPLETE = 'https://storage.googleapis.com/genai-assets/monedaventura/sfx-halloween-complete.mp3';
export const SFX_CHRISTMAS_COMPLETE = 'https://storage.googleapis.com/genai-assets/monedaventura/sfx-christmas-complete.mp3';
export const SFX_BIRTHDAY_CHEST = 'https://storage.googleapis.com/genai-assets/monedaventura/sfx-birthday-chest.mp3';
export const SFX_HALLOWEEN_CHEST = 'https://storage.googleapis.com/genai-assets/monedaventura/sfx-halloween-chest.mp3';
export const SFX_CHRISTMAS_CHEST = 'https://storage.googleapis.com/genai-assets/monedaventura/sfx-christmas-chest.mp3';

export type Landscape = 'birthday' | 'halloween' | 'christmas';

export const landscapes: Record<Landscape, { name: string; bg: string; pathColor: string; mainColor: string; logo: string; }> = {
  birthday: { name: 'Cumpleaños 🎂', bg: BIRTHDAY_BG_URL, pathColor: '#FFC0CB', mainColor: '#FF69B4', logo: BIRTHDAY_LOGO_URL },
  halloween: { name: 'Halloween 🎃', bg: HALLOWEEN_BG_URL, pathColor: '#A06CD5', mainColor: '#F28C28', logo: HALLOWEEN_LOGO_URL },
  christmas: { name: 'Navidad 🎄', bg: CHRISTMAS_BG_URL, pathColor: '#B0E0E6', mainColor: '#D92A2A', logo: CHRISTMAS_LOGO_URL },
};

export const missionsData: Record<Landscape, any[]> = {
  birthday: [
    { id: 'b1', name: 'Meta de ahorro', description: "Define cuánto quieres ahorrar y para qué.", icon: MISSION_ICON_NOTEBOOK_URL, pos: { top: '10%', left: '10%' } },
    { id: 'b2', name: 'Compra necesaria', description: "Elige solo lo que realmente necesitas.", icon: MISSION_ICON_CART_URL, pos: { top: '10%', left: '80%' } },
    { id: 'b3', name: 'Globo dorado', description: "Sigue pistas para encontrar el globo especial.", icon: ICON_BALLOON, pos: { top: '40%', left: '90%' } },
    { id: 'b4', name: 'Puzzle de tarta', description: "Arma el pastel correcto sin gastar de más.", icon: ICON_CAKE, pos: { top: '70%', left: '80%' } },
    { id: 'b5', name: 'Ordena regalos', description: "Organiza los regalos según prioridad.", icon: MISSION_ICON_GIFT_URL, pos: { top: '80%', left: '50%' } },
    { id: 'b6', name: 'Quiz: ¿Necesidad?', description: "Responde preguntas sobre compras inteligentes.", icon: ICON_QUESTION, pos: { top: '70%', left: '20%' } },
    { id: 'b7', name: 'Ahorro para piñata', description: "Guarda monedas para desbloquear la piñata.", icon: ICON_PINATA, pos: { top: '40%', left: '10%' } },
    { id: 'b8', name: 'Arma tu mochila', description: "Selecciona lo esencial para continuar la aventura.", icon: ICON_BACKPACK, pos: { top: '50%', left: '25%' } },
    { id: 'b9', name: 'Encuentra sorpresa', description: "Sigue pistas y encuentra la sorpresa escondida.", icon: ICON_SURPRISE, pos: { top: '50%', left: '75%' } },
    { id: 'b10', name: 'Cofre Mágico', description: "¡Has completado el paisaje, abre el cofre final!", icon: CHEST_MAIN_ICON_URL, pos: { top: '50%', left: '50%' } },
  ],
  halloween: [
    { id: 'h1', name: 'Alcancía Fantasma', description: "Deposita monedas en la alcancía del espectro.", icon: ICON_GHOST_PIGGY, pos: { top: '10%', left: '10%' } },
    { id: 'h2', name: 'Disfraz Esencial', description: "Selecciona solo lo esencial para tu disfraz.", icon: ICON_COSTUME, pos: { top: '10%', left: '80%' } },
    { id: 'h3', name: 'Calabaza Dorada', description: "Sigue pistas para localizar la calabaza dorada.", icon: MISSION_ICON_PUMPKIN_URL, pos: { top: '40%', left: '90%' } },
    { id: 'h4', name: 'Laberinto del Ahorro', description: "Avanza solo si has ahorrado suficientes monedas.", icon: MISSION_ICON_LABYRINTH_URL, pos: { top: '70%', left: '80%' } },
    { id: 'h5', name: 'Clasifica Dulces', description: "Decide cuáles dulces comprar y cuáles ahorrar.", icon: ICON_SWEETS, pos: { top: '80%', left: '50%' } },
    { id: 'h6', name: 'Quiz de Gasto', description: "Responde preguntas de finanzas básicas.", icon: ICON_QUESTION, pos: { top: '70%', left: '20%' } },
    { id: 'h7', name: 'Comparte Monedas', description: "Decide cuántas monedas compartir.", icon: ICON_COINS, pos: { top: '40%', left: '10%' } },
    { id: 'h8', name: 'Objeto Encantado', description: "Selecciona solo objetos necesarios.", icon: ICON_MAGIC_OBJECT, pos: { top: '50%', left: '25%' } },
    { id: 'h9', name: 'Tesoro Oculto', description: "Sigue pistas para encontrar el tesoro.", icon: MISSION_ICON_TREASURE_URL, pos: { top: '50%', left: '75%' } },
    { id: 'h10', name: 'Cofre Final', description: "¡Completa Halloween y abre el cofre final!", icon: CHEST_MAIN_ICON_URL, pos: { top: '50%', left: '50%' } },
  ],
  christmas: [
    { id: 'c1', name: 'Planifica Gastos', description: "Decide cuánto gastar en regalos, decoración y comida.", icon: ICON_LIST, pos: { top: '10%', left: '10%' } },
    { id: 'c2', name: 'Banquete Esencial', description: "Selecciona solo lo que necesitas.", icon: ICON_BASKET, pos: { top: '10%', left: '80%' } },
    { id: 'c3', name: 'Ornamento Dorado', description: "Sigue pistas para localizar el ornamento.", icon: ICON_ORNAMENT, pos: { top: '40%', left: '90%' } },
    { id: 'c4', name: 'Banquete Próspero', description: "Distribuye monedas sin excederte del presupuesto.", icon: ICON_TABLE, pos: { top: '70%', left: '80%' } },
    { id: 'c5', name: 'Organiza Regalos', description: "Organiza los regalos según importancia.", icon: MISSION_ICON_GIFT_URL, pos: { top: '80%', left: '50%' } },
    { id: 'c6', name: 'Quiz de Admin', description: "Responde preguntas sobre buena administración.", icon: ICON_QUESTION, pos: { top: '70%', left: '20%' } },
    { id: 'c7', name: 'Regalo Especial', description: "Guarda monedas para un regalo especial.", icon: MISSION_ICON_TREASURE_URL, pos: { top: '40%', left: '10%' } },
    { id: 'c8', name: 'Puzzle de Árbol', description: "Arma el árbol correctamente sin gastar demás.", icon: ICON_TREE, pos: { top: '50%', left: '25%' } },
    { id: 'c9', name: 'Decora la Sala', description: "Decora sin exceder el presupuesto.", icon: ICON_DECORATION, pos: { top: '50%', left: '75%' } },
    { id: 'c10', name: 'Cofre del Polo', description: "¡Completa Navidad y abre el cofre final!", icon: CHEST_MAIN_ICON_URL, pos: { top: '50%', left: '50%' } },
  ],
};


export interface SavingsGoal {
  id: string;
  name: string;
  target: number;
  current: number;
  isJoint?: boolean;
}

// REFACTOR: Redefine the User type for individual accounts.
export interface User {
  name: string;
  role: UserRole;
  password: string; // 4 digits for child, 6 for parent
  // Child-specific, optional properties
  avatarId?: AvatarId;
  customAvatarUrl?: string;
  coins?: number;
  stars?: number;
  trophies?: number;
  level?: number;
  goals?: SavingsGoal[];
  motivationalMessages?: string[];
  completedMissions?: string[];
}