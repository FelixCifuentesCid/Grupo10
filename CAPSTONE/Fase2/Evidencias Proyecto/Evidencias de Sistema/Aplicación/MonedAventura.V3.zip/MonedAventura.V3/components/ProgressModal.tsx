import React, { useMemo, useState, useEffect, useRef } from 'react';
import { User, AVATARS, missionsData } from '../types';
import { CoinIcon, MedalIcon, ChartPieIcon, LightBulbIcon, CheckBadgeIcon } from './Icons';

interface ProgressModalProps {
  user: User;
  userRole: 'child' | 'parent';
  onClose: () => void;
}

const LEVEL_NAMES: { [key: number]: string } = { 1: 'Explorador Novato', 2: 'Ahorrista Astuto', 3: 'Maestro del Ahorro' };
const ALL_MISSIONS = Object.values(missionsData).flat();
const TOTAL_MISSIONS = ALL_MISSIONS.length;

const childMotivationalMessages = [
    "¡Sigue así, vas increíble!",
    "¡Tu constancia te llevará muy lejos!",
    "¡Cada moneda que ahorras es un paso hacia tus sueños!",
    "¡Eres un verdadero genio de las finanzas!",
    "¡El zorro Fíli está muy orgulloso de ti!"
];

const parentRecommendations = [
    "Felicita a tu hijo/a por su esfuerzo de esta semana.",
    "Motívalo a ahorrar más con pequeñas metas.",
    "Revisa sus misiones completadas para acompañarlo en su aprendizaje.",
    "Conversen sobre la diferencia entre una 'necesidad' y un 'deseo'.",
    "Establezcan una pequeña 'paga' semanal para que pueda practicar sus habilidades."
];

const getAchievements = (user: User) => [
    { id: 'first_mission', name: 'Primer Paso', description: 'Completaste tu primera misión.', unlocked: (user.completedMissions?.length ?? 0) >= 1 },
    { id: 'level_2', name: 'Ahorrador Nato', description: 'Alcanzaste el nivel 2.', unlocked: (user.level ?? 1) >= 2 },
    { id: 'birthday_complete', name: 'Rey de la Fiesta', description: 'Completaste el mundo de Cumpleaños.', unlocked: missionsData.birthday.every(m => user.completedMissions?.includes(m.id)) },
    { id: 'halloween_complete', name: 'Cazador de Dulces', description: 'Completaste el mundo de Halloween.', unlocked: missionsData.halloween.every(m => user.completedMissions?.includes(m.id)) },
    { id: 'rich', name: 'Pequeño Magnate', description: 'Ahorraste más de 300 monedas.', unlocked: (user.coins ?? 0) >= 300 },
    { id: 'ten_missions', name: 'Explorador Experto', description: 'Completaste 10 misiones.', unlocked: (user.completedMissions?.length ?? 0) >= 10 },
];

// --- TUTORIAL CONFIGURATION ---
const childTutorialSteps = [
  { targetId: 'progress-header', text: '¡Hola! Aquí puedes ver tu nombre y tu nivel de aventurero financiero.', position: 'bottom' },
  { targetId: 'progress-bar-container', text: 'Esta barra muestra tu progreso total en MonedAventura. ¡Llénala completando misiones!', position: 'bottom' },
  { targetId: 'stats-cards', text: 'Aquí tienes un resumen rápido de tus misiones, monedas y tu nivel actual.', position: 'bottom' },
  { targetId: 'achievements-section', text: '¡Colecciona todas las medallas! Se desbloquean al alcanzar metas importantes.', position: 'top' },
];

const parentTutorialSteps = [
  { targetId: 'progress-header', text: 'Este es el resumen del progreso de tu hijo/a.', position: 'bottom' },
  { targetId: 'summary-chart', text: 'Este gráfico interactivo muestra su progreso semanal. ¡Pasa el ratón sobre las barras para ver los detalles!', position: 'bottom' },
  { targetId: 'parent-recommendation', text: 'Aquí encontrarás consejos personalizados para apoyar su aprendizaje financiero.', position: 'top' },
];

const TutorialOverlay: React.FC<{
    userRole: 'child' | 'parent';
    onFinish: () => void;
}> = ({ userRole, onFinish }) => {
    const [step, setStep] = useState(0);
    const [highlightStyle, setHighlightStyle] = useState({});
    const [tooltipStyle, setTooltipStyle] = useState({});

    const steps = userRole === 'child' ? childTutorialSteps : parentTutorialSteps;
    const currentStep = steps[step];

    useEffect(() => {
        const targetElement = document.getElementById(currentStep.targetId);
        if (targetElement) {
            const rect = targetElement.getBoundingClientRect();
            // We need to get the modal's position to calculate relative coordinates
            const modal = targetElement.closest('[role="dialog"]');
            const modalRect = modal ? modal.getBoundingClientRect() : { top: 0, left: 0 };
            
            setHighlightStyle({
                top: `${rect.top - modalRect.top}px`,
                left: `${rect.left - modalRect.left}px`,
                width: `${rect.width}px`,
                height: `${rect.height}px`,
            });
            
            const tooltipTop = currentStep.position === 'bottom' 
                ? `${rect.bottom - modalRect.top + 10}px` 
                : `${rect.top - modalRect.top - 10}px`;

            setTooltipStyle({
                top: tooltipTop,
                left: '50%',
                transform: `translateX(-50%) ${currentStep.position === 'top' ? 'translateY(-100%)' : ''}`,
            });
        }
    }, [step, currentStep]);

    const handleNext = () => {
        if (step < steps.length - 1) {
            setStep(s => s + 1);
        } else {
            onFinish();
        }
    };

    return (
        <div className="absolute inset-0 bg-black/75 z-50 animate-modal-fade-in p-4">
            <div className="absolute bg-transparent rounded-lg transition-all duration-500" style={{ ...highlightStyle, boxShadow: '0 0 0 9999px rgba(0,0,0,0.75)' }}></div>
            <div className="absolute w-full max-w-xs transition-all duration-500" style={tooltipStyle}>
                <div className="bg-white rounded-xl p-4 text-center shadow-2xl relative">
                    <p className="text-gray-700 font-semibold">{currentStep.text}</p>
                    <div className="flex justify-between items-center mt-4">
                        <span className="text-sm font-bold text-gray-500">{step + 1} / {steps.length}</span>
                        <button onClick={handleNext} className="bg-blue-500 text-white font-bold py-2 px-6 rounded-full">
                            {step === steps.length - 1 ? '¡Entendido!' : 'Siguiente'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};


const StatCard: React.FC<{ value: string | number, label: string, icon: React.ReactNode, color: string }> = ({ value, label, icon, color }) => (
    <div className="flex-1 bg-white p-3 rounded-xl shadow-sm text-center">
        <div className={`w-10 h-10 mx-auto rounded-full flex items-center justify-center ${color}`}>
            {icon}
        </div>
        <p className="text-xl font-black text-gray-800 mt-2">{value}</p>
        <p className="text-xs font-bold text-gray-500">{label}</p>
    </div>
);

const InteractiveBarChart: React.FC<{ data: Array<{ week: string; missions: number; coins: number }> }> = ({ data }) => {
    const [tooltip, setTooltip] = useState<{ visible: boolean; content: string; x: number; y: number } | null>(null);
    const chartRef = useRef<HTMLDivElement>(null);

    const maxMissions = useMemo(() => Math.max(...data.map(d => d.missions), 0) || 1, [data]);

    const handleMouseMove = (e: React.MouseEvent, weekData: { week: string; missions: number; coins: number }) => {
        if (!chartRef.current) return;
        const rect = chartRef.current.getBoundingClientRect();
        setTooltip({
            visible: true,
            content: `<strong>${weekData.week}</strong><br/>Misiones: ${weekData.missions}<br/>Monedas: ${weekData.coins} 💰`,
            x: e.clientX - rect.left,
            y: e.clientY - rect.top,
        });
    };

    const handleMouseLeave = () => {
        setTooltip(null);
    };

    return (
        <div ref={chartRef} className="relative bg-white p-4 rounded-xl shadow-sm h-64" onMouseLeave={handleMouseLeave}>
            <p className="font-bold text-center text-gray-600 text-sm mb-2">Misiones Completadas por Semana</p>
            <div className="flex justify-around items-end h-48 border-b-2 border-gray-200">
                {data.map((d, i) => (
                    <div
                        key={i}
                        className="flex-1 h-full flex flex-col-reverse items-center group relative pt-4"
                        onMouseMove={(e) => handleMouseMove(e, d)}
                    >
                        <span className="text-xs font-bold text-gray-500 mt-1">{d.week.replace(' ', '\n')}</span>
                        <div
                            className="w-3/4 bg-purple-400 hover:bg-purple-600 rounded-t-md transition-all duration-300"
                            style={{ height: `${(d.missions / maxMissions) * 100}%` }}
                        ></div>
                    </div>
                ))}
            </div>
             <p className="text-xs text-center text-gray-400 mt-2">Pasa el mouse sobre las barras para ver detalles.</p>
            {tooltip && tooltip.visible && (
                <div
                    className="absolute bg-black/80 text-white text-xs rounded-lg p-2 transition-opacity duration-200 pointer-events-none z-10"
                    style={{
                        left: tooltip.x,
                        top: tooltip.y,
                        transform: 'translate(-50%, -110%)', // Position above cursor
                    }}
                    dangerouslySetInnerHTML={{ __html: tooltip.content }}
                ></div>
            )}
        </div>
    );
};


const ChildProgressView: React.FC<{ user: User }> = ({ user }) => {
    const progress = Math.min(((user.completedMissions?.length ?? 0) / TOTAL_MISSIONS) * 100, 100);
    const achievements = getAchievements(user);
    const motivationalMessage = useMemo(() => childMotivationalMessages[Math.floor(Math.random() * childMotivationalMessages.length)], []);
    const avatarUrl = user.customAvatarUrl || AVATARS[user.avatarId ?? 'boy'].image;

    return (
        <div className="p-4 space-y-4">
            <div id="progress-header" className="text-center">
                <img src={avatarUrl} alt={user.name} className="w-20 h-20 rounded-full mx-auto border-4 border-white shadow-lg object-cover" />
                <h2 className="text-2xl font-black text-gray-800 mt-2">{user.name}</h2>
                <p className="font-bold text-green-600">{LEVEL_NAMES[user.level ?? 1]}</p>
            </div>

            <div id="progress-bar-container">
                <p className="font-bold text-gray-600 mb-1 text-sm">Progreso Total</p>
                <div className="w-full bg-gray-200 rounded-full h-4">
                    <div className="bg-gradient-to-r from-green-400 to-blue-500 h-4 rounded-full transition-all duration-1000 ease-out" style={{ width: `${progress}%` }}></div>
                </div>
            </div>

            <div id="stats-cards" className="flex gap-3">
                <StatCard value={user.completedMissions?.length ?? 0} label="Misiones" icon={<CheckBadgeIcon className="w-6 h-6 text-green-800" />} color="bg-green-200" />
                <StatCard value={user.coins ?? 0} label="Monedas" icon={<CoinIcon className="w-6 h-6 text-yellow-800" />} color="bg-yellow-200" />
                <StatCard value={user.level ?? 1} label="Nivel" icon={<MedalIcon className="w-6 h-6 text-orange-800" />} color="bg-orange-200" />
            </div>

            <section id="achievements-section">
                <h3 className="font-bold text-lg text-gray-700">Logros Desbloqueados</h3>
                <div className="grid grid-cols-3 gap-3 mt-2">
                    {achievements.map(ach => (
                        <div key={ach.id} className={`p-2 rounded-lg text-center transition-all duration-300 ${ach.unlocked ? 'bg-yellow-100' : 'bg-gray-100 opacity-60'}`} title={ach.description}>
                            <div className={`w-10 h-10 mx-auto rounded-full flex items-center justify-center ${ach.unlocked ? 'bg-yellow-400 text-white animate-achievement-glow' : 'bg-gray-300 text-gray-500'}`}>
                                <MedalIcon className="w-6 h-6" />
                            </div>
                            <p className="text-xs font-bold text-gray-600 mt-1">{ach.name}</p>
                        </div>
                    ))}
                </div>
            </section>
            
            <section className="text-center bg-blue-100 p-3 rounded-xl">
                 <p className="font-bold text-sm text-blue-800">"{motivationalMessage}"</p>
            </section>
        </div>
    );
};

const ParentProgressView: React.FC<{ child: User }> = ({ child }) => {
    const recommendation = useMemo(() => parentRecommendations[Math.floor(Math.random() * parentRecommendations.length)], []);
    const childAvatarUrl = child.customAvatarUrl || AVATARS[child.avatarId ?? 'boy'].image;

    // Mock weekly data for the interactive chart
    const weeklyData = useMemo(() => [
        { week: 'Hace 3 sem', missions: 2, coins: 30 },
        { week: 'Hace 2 sem', missions: 1, coins: 15 },
        { week: 'Semana Pasada', missions: 4, coins: 60 },
        { week: 'Esta Semana', missions: (child.completedMissions?.length ?? 0) > 7 ? 3 : 1, coins: 45 },
    ], [child.completedMissions]);

    return (
        <div className="p-4 space-y-4">
             <div id="progress-header" className="flex items-center gap-3">
                <img src={childAvatarUrl} alt={child.name} className="w-16 h-16 rounded-full border-4 border-white shadow-lg object-cover" />
                <div>
                    <p className="text-sm font-bold text-gray-500">Progreso de:</p>
                    <h2 className="text-2xl font-black text-gray-800">{child.name}</h2>
                </div>
            </div>

            <section id="summary-chart">
                <h3 className="font-bold text-lg text-gray-700 mb-2">Progreso Semanal Interactivo</h3>
                <div className="grid grid-cols-3 gap-2 text-center mb-3">
                    <div className="bg-white p-2 rounded-lg shadow-sm">
                        <p className="text-xs font-bold text-gray-500">Nivel</p>
                        <p className="font-black text-purple-700">{child.level ?? 1}</p>
                    </div>
                     <div className="bg-white p-2 rounded-lg shadow-sm">
                        <p className="text-xs font-bold text-gray-500">Misiones Totales</p>
                        <p className="font-black text-purple-700">{child.completedMissions?.length ?? 0}</p>
                    </div>
                     <div className="bg-white p-2 rounded-lg shadow-sm">
                        <p className="text-xs font-bold text-gray-500">Monedas Totales</p>
                        <p className="font-black text-purple-700">{child.coins ?? 0} 💰</p>
                    </div>
                </div>
                <InteractiveBarChart data={weeklyData} />
            </section>
            
            <section id="parent-recommendation" className="bg-orange-100 p-3 rounded-xl flex items-start gap-3">
                <div className="bg-orange-400 text-white rounded-full p-2 mt-1">
                    <LightBulbIcon className="w-6 h-6" />
                </div>
                <div>
                    <h3 className="font-bold text-orange-800">Recomendación</h3>
                    <p className="text-sm text-orange-700">"{recommendation}"</p>
                </div>
            </section>
        </div>
    );
};

const ProgressModal: React.FC<ProgressModalProps> = ({ user, userRole, onClose }) => {
    const headerColor = userRole === 'child' ? 'bg-gradient-to-r from-green-400 to-blue-500' : 'bg-gradient-to-r from-purple-500 to-indigo-600';

    const [showTutorial, setShowTutorial] = useState(false);
    const tutorialKey = `monedaventura_progress_tutorial_${userRole}_seen`;

    useEffect(() => {
        const hasSeenTutorial = localStorage.getItem(tutorialKey);
        if (!hasSeenTutorial) {
            // Use a timeout to ensure the modal DOM is ready for the tutorial to measure
            const timer = setTimeout(() => setShowTutorial(true), 200);
            return () => clearTimeout(timer);
        }
    }, [tutorialKey]);

    const handleFinishTutorial = () => {
        setShowTutorial(false);
        localStorage.setItem(tutorialKey, 'true');
    };

    return (
        <>
        <style>{`
            @keyframes modal-fade-in { from { opacity: 0; } to { opacity: 1; } }
            @keyframes modal-slide-up { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
            .animate-modal-fade-in { animation: modal-fade-in 0.3s ease-out forwards; }
            .animate-modal-slide-up { animation: modal-slide-up 0.4s ease-out forwards; }
            @keyframes achievement-glow {
                0%, 100% { 
                    box-shadow: 0 0 8px rgba(250, 204, 21, 0.5); 
                    transform: scale(1) rotate(0deg);
                }
                50% { 
                    box-shadow: 0 0 20px 8px rgba(250, 204, 21, 0.8); 
                    transform: scale(1.1) rotate(-5deg);
                }
            }
            .animate-achievement-glow {
                animation: achievement-glow 2.5s ease-in-out infinite;
            }
        `}</style>
        <div 
            className="absolute inset-0 bg-black/60 flex items-center justify-center p-4 z-50 animate-modal-fade-in" 
            onClick={onClose}
        >
            <div 
                role="dialog"
                className="bg-gray-100 rounded-2xl w-full max-w-sm max-h-[90vh] flex flex-col shadow-2xl animate-modal-slide-up relative"
                onClick={(e) => e.stopPropagation()}
            >
                {showTutorial && <TutorialOverlay userRole={userRole} onFinish={handleFinishTutorial} />}
                <header className={`p-3 rounded-t-2xl text-white font-black text-xl text-center relative ${headerColor}`}>
                    <h2>{userRole === 'child' ? 'Mi Progreso' : 'Resumen de Progreso'}</h2>
                     <button onClick={onClose} className="absolute top-1/2 -translate-y-1/2 right-3 bg-white/20 hover:bg-white/40 w-8 h-8 rounded-full font-bold transition-colors">
                        X
                    </button>
                </header>

                <main className="overflow-y-auto">
                   {userRole === 'child' ? <ChildProgressView user={user} /> : <ParentProgressView child={user} />}
                </main>

                <footer className="p-3 border-t">
                     <button onClick={onClose} className="w-full bg-gradient-to-r from-gray-500 to-gray-700 text-white font-bold py-2 rounded-full transition-transform active:scale-95 hover:from-gray-600 hover:to-gray-800 shadow-md">
                        Volver
                    </button>
                </footer>
            </div>
        </div>
        </>
    );
};

export default ProgressModal;