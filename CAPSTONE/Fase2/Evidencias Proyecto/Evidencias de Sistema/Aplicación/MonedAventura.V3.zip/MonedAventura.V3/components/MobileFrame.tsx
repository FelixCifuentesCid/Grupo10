import React from 'react';
import { WifiIcon, BatteryIcon } from './Icons';

interface MobileFrameProps {
  children: React.ReactNode;
  bottomNav: React.ReactNode | null;
}

const MobileFrame: React.FC<MobileFrameProps> = ({ children, bottomNav }) => {
  return (
    <div className="w-[375px] h-[812px] bg-white rounded-[40px] shadow-2xl overflow-hidden relative flex flex-col border-4 border-black">
      {/* Notch */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-8 bg-black rounded-b-2xl z-20"></div>

      {/* Status Bar */}
      <div className="absolute top-0 left-0 right-0 h-11 px-6 flex justify-between items-center z-10 text-black font-bold text-sm">
        <span className="w-14">9:41</span>
        <div className="flex items-center gap-1.5">
          <WifiIcon className="w-4 h-4" />
          <BatteryIcon className="w-6 h-6" />
        </div>
      </div>

      {/* Main Content Area */}
      <div className="pt-11 flex-grow flex flex-col overflow-hidden">
        <main className={`flex-grow overflow-y-auto bg-[#F9F7F0] ${!bottomNav ? 'pb-0' : ''}`}>
            {children}
        </main>
        {bottomNav && (
            <footer>
                {bottomNav}
            </footer>
        )}
      </div>
    </div>
  );
};

export default MobileFrame;